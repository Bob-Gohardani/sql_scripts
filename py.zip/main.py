"""
The script connects to the SQL instance and populate tables
with the newest data form the MIDSERVER
"""
import logging
import os
from pathlib import Path
import shelve
import dbm
from datetime import date
import sqlalchemy
# Importing custom-made packages
from assets.config import SourceConfiguration
from assets.custom_functions import create_shelve_file
from assets.custom_classes import DatabaseConnectionWrapper, DataPreprocessingClass, SQLOperationClass
import assets.logging_system


# Logging system build in config file.
LOGGER = logging.getLogger(__name__)
CONFIG = SourceConfiguration()

LOGGER.info("[*] STARTING THE INSERT/UPDATE PROCESS")
LOGGER.info("[*] Setting up connection to the SQL Server")

# Creating new instance of the database.
DB_INSTANCE = DatabaseConnectionWrapper(CONFIG.SQL_SERVER, CONFIG.SQL_DATABASE, CONFIG.SQL_DRIVER)
DB_INSTANCE.create_engine()

# Validate the connection to the SQL Server
try:
    DB_INSTANCE.create_connection
except sqlalchemy.exc.OperationalError:
    # Exception raised for errors that are related to the database's operation,
    # e.g. an unexpected disconnection occures, the data source name is not found.
    WARNING_MESSAGE = 'Problem with database connection. '
    if DatabaseConnectionWrapper.ping_sql_server(CONFIG.SQL_SERVER):
        EXCEPTION_MESSAGE = WARNING_MESSAGE + 'Possible scenario: SQL instance is down. \
            Check Server address or contact SQL Support team.\n'
    else:
        EXCEPTION_MESSAGE = WARNING_MESSAGE + "Possible scenario: SQL instance is working, \
            but script couldn't connect. Check server name or schema in the config file.\n"
    LOGGER.critical('[-] OperationalError caught %s', EXCEPTION_MESSAGE, exc_info=True)
    raise ConnectionError(EXCEPTION_MESSAGE)
except sqlalchemy.exc.ProgrammingError: # !
    # Exception raised for programming errors, e.g. table, schema or database not found.
    WARNING_MESSAGE = 'Problem with database connection. '
    EXCEPTION_MESSAGE = WARNING_MESSAGE + 'Possible scenario: Check database name in the \
        config file.\n'
    LOGGER.critical('[-] ProgrammingError caught %s', EXCEPTION_MESSAGE, exc_info=True)
    raise ConnectionError(EXCEPTION_MESSAGE)
except sqlalchemy.exc.InterfaceError:
    # Exception raised for errors that are realted to the database interface
    # rather then the database itself, e.g the wrong driver type.
    WARNING_MESSAGE = 'Problem with database connection. '
    EXCEPTION_MESSAGE = WARNING_MESSAGE + 'Possible scenario: Check driver in the config \
        file.\n'
    LOGGER.critical('[-] InterfaceError caught %s', EXCEPTION_MESSAGE, exc_info=True)
    raise ConnectionError(EXCEPTION_MESSAGE)
except Exception as vague_error:
    WARNING_MESSAGE = 'Problem with database connection. '
    EXCEPTION_MESSAGE = WARNING_MESSAGE + "Type: {} args:{}\n".format(type(vague_error).__name__,
                                                                      vague_error.args)
    LOGGER.critical('[-] Vague error caught %s', EXCEPTION_MESSAGE, exc_info=True)
else:
    LOGGER.info("[+] Connection with SQL server established correctly")


LOGGER.info("[*] Reading content of the shelve files.")
# Reading content of the shelve files
SHELVE_FOLDER_PATH = os.path.join(os.getcwd(), CONFIG.SHELVE_FOLDER)
SHELVE_FILES_PATH = os.path.join(SHELVE_FOLDER_PATH, CONFIG.SHELVE_FILENAME)
if not Path(SHELVE_FOLDER_PATH).is_dir():
    LOGGER.warning("No shelve folder, no shelve files found. Creating new shelve files.")
    os.mkdir(SHELVE_FOLDER_PATH)
    shelve_obj = create_shelve_file(SHELVE_FILES_PATH)
    LOGGER.info("Shelve file created correctly")
else:
    try:
        shelve_obj = shelve.open(filename=SHELVE_FILES_PATH, flag='w', writeback=True)
    except dbm.error:
        LOGGER.error("Problems with the shelve files. Creating new shelve files.", exc_info=True)
        shelve_obj = create_shelve_file(SHELVE_FILES_PATH)
        LOGGER.info("Shelve file created correctly.")
SHELVE_CONTENT = shelve_obj['items']
LOGGER.info("[+] Content from the shelve files read correctly.")


LOGGER.info("[*] Connecting to the MidServer.")
# Checking if mapped drive exisits (The Mid Server)
if not os.path.isdir(CONFIG.MID_SERVER_PATH):
    EXCEPTION_MESSAGE = "(MID SERVER) Directory {} doesn't exists. Possible scenario: Wrong path \
        stored in the config.py file\n".format(CONFIG.MID_SERVER_PATH)
    LOGGER.critical("[-] FileNotFoundError raised %s", EXCEPTION_MESSAGE, exc_info=True)
    shelve_obj.close()
    raise FileNotFoundError(EXCEPTION_MESSAGE)
LOGGER.info("[+] Connection with MidServer established correctly.")


LOGGER.info("[*] Gathering all files that are stored on the MID Server.")
# Gathering all files that are stored on the MID Server.
FILES_LIST = [file_ for file_ in os.listdir(CONFIG.MID_SERVER_PATH)
              if os.path.isfile(os.path.join(CONFIG.MID_SERVER_PATH, file_))]
if not FILES_LIST:
    EXCEPTION_MESSAGE = "(MID SERVER) exists, but it is empty.\n"
    LOGGER.critical("[-] FileNotFoundError raised %s", EXCEPTION_MESSAGE, exc_info=True)
    shelve_obj.close()
    raise FileNotFoundError(EXCEPTION_MESSAGE)
LOGGER.info("[+] Files gathered correctly.")


for index, item in enumerate(SHELVE_CONTENT):
    LOGGER.info("[*] Updating %s table.", item['table_name'])

    filename = item['filename']
    last_update = item['last_update']
    columns_to_correct = item['columns_to_be_corrected']
    drop_duplicates_on = item['drop_duplicates_on']
    columns_to_save = item['columns_to_save']
    
    # Create new DataPreprocessingClass object
    table_object = DataPreprocessingClass(filename=filename,
                                          last_update=last_update,
                                          columns_to_correct=columns_to_correct,
                                          drop_duplicates_on=drop_duplicates_on)

    # From file list extracting only valid files
    table_object.extract_and_sort(FILES_LIST)

    # Filter on last update - receing delta
    filtered_files_list = table_object.filter_by_last_update()
    # filtered_files_list = filtered_files_list[:-1]

    if not filtered_files_list:
        LOGGER.warning("No new data.")
        continue

    # Create absolut paths
    filtered_file_path_list = [os.path.join(CONFIG.MID_SERVER_PATH, file_item) for file_item in filtered_files_list]

    # Concatenate all files into one pandas dataframe
    final_dataframe = table_object.concatenate_files(filtered_file_path_list, CONFIG.CSV_ENCODING)
    try:
        # Drop not important columns
        final_dataframe = DataPreprocessingClass.validate_and_drop_columns(dataframe=final_dataframe, 
                                                                           columns_to_save=columns_to_save)
    except KeyError:
        # Write the message into the log file about missing column in the dataframe.
        LOGGER.error(f"Wrong structure of {filename} file. Check if the name of the columns are correct.")
        continue
    
    # Create new SQLOperationClass object
    SQL_operation_object = SQLOperationClass(DB_INSTANCE.engine)
    table_name = item['table_name']
    sql_schema = item['sql_schema']
    
    if item['last_update']:
        temp_table_name = f'temp_{table_name}'
        if item['merge']:
            SQL_operation_object.to_sql(dataframe=final_dataframe, 
                                        schema=sql_schema, 
                                        table_name=temp_table_name)
            if item['drop_duplicates_on'] == 'All':
                drop_duplicates_on = list(final_dataframe)
            else:
                drop_duplicates_on = item['drop_duplicates_on']

            full_columns_list = list(final_dataframe)
            SQL_operation_object.merge_tables(main_table=table_name,
                                              temp_table=temp_table_name,
                                              merge_on=drop_duplicates_on,
                                              full_columns_list=full_columns_list,
                                              schema=sql_schema)

            # SQL_operation_object.drop_table(schema=sql_schema, table_name=temp_table_name)
        else:
            SQL_operation_object.to_sql(dataframe=final_dataframe,
                                        schema=sql_schema,
                                        table_name=table_name,
                                        if_exists="append")
    else:
        SQL_operation_object.to_sql(dataframe=final_dataframe,
                                    schema=sql_schema,
                                    table_name=table_name)

    # shelve_obj['items'][index]['last_update'] = DataPreprocessingClass.get_date_from_string(filtered_files_list[-1])
    print(shelve_obj['items'][index]['last_update'])
    # print(DataPreprocessingClass.get_date_from_string(filtered_files_list[-1]))
    shelve_obj['items'][index]['last_update'] = date.today()
    LOGGER.info("[+] Table %s updated.", item['table_name'])

shelve_obj.sync()
shelve_obj.close()

LOGGER.info("[+] END OF THE INSERT/UPDATE PROCESS.\n")
