"""
The script connects to the SQL instance, reads the sql files,
and execute them in the database.
"""
import logging
import os
import sqlalchemy
# Importing custom-made packages
from assets.config import SourceConfiguration
from assets.custom_classes import DatabaseConnectionWrapper
import assets.logging_system


# Logging system build in config file.
LOGGER = logging.getLogger(__name__)
CONFIG = SourceConfiguration()

LOGGER.info("[*] STARTING THE SQL MANIPULATION PROCESS.")

# Creating new instance of the database_connection class.
DB_INSTANCE = DatabaseConnectionWrapper(CONFIG.SQL_SERVER, CONFIG.SQL_DATABASE, CONFIG.SQL_DRIVER)
DB_INSTANCE.create_engine()


CWD = os.getcwd()
SQL_QUERY_PATH = os.path.join(CWD, CONFIG.SQL_PATH, 'SqlFixed')
FILES_LIST = [os.path.join(SQL_QUERY_PATH, file_) for file_ in os.listdir(SQL_QUERY_PATH)
              if file_.endswith('.sql')]

if CONFIG.SQL_DATABASE == 'rwe_etl_production' and os.path.join(SQL_QUERY_PATH, '0. Avaya_table.sql') in FILES_LIST:
    FILES_LIST.remove(os.path.join(SQL_QUERY_PATH, '0. Avaya_table.sql'))

for file_ in FILES_LIST:
    file_basename = os.path.basename(file_)
    LOGGER.info('[*] Starting file %s.', file_basename)
    with open(file_, 'r') as sql_file:
        raw_sql_query = " ".join(sql_file.readlines())
        if raw_sql_query.endswith(';'):
            raw_sql_query = raw_sql_query[:-1]
        sql_query_list = raw_sql_query.split(";")

        with DB_INSTANCE.create_connection() as coursor:
            transaction = coursor.begin()
            for query in sql_query_list:
                try:
                    coursor.execute(query)
                except sqlalchemy.exc.ProgrammingError:
                    LOGGER.critical('[-] Problems with %s file. Check the correctnes of \this file.', file_basename, exc_info=True)
            try:
                transaction.commit()
            except Exception as err:
                transaction.rollback()
                LOGGER.critical(exc_info=True)
            else:
                LOGGER.info('[+] File %s executed correctly.', file_basename)

LOGGER.info("[+] END OF THE SQL MANIPULATION PROCESS.\n")
