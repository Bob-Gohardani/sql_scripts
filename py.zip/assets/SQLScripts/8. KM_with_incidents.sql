DROP TABLE IF EXISTS prod.KM_with_incidents;

SELECT x.*
INTO prod.KM_with_incidents
FROM (

		SELECT c.number AS 'number/task',
			NULL AS sla,
			NULL AS has_breached,
			c.opened_at_date,
			c.closed_at_date,
			c.[service_offering.supported_by],
			CAST(ISNULL(c.assignment_group, NULL) AS varchar) AS assignment_group,
			c.category,
			'KM-01' AS 'Flag',
			'Service Desk Tickets Escalated to Level 2' AS Name
		FROM metrics.KM_01 c
	
	UNION

	SELECT c.number AS 'number/task',
		NULL AS sla,
		NULL AS has_breached,
		c.opened_at_date,
		c.closed_at_date,
		NULL AS [service_offering.supported_by],
		CAST(ISNULL(c.assignment_group, NULL) AS varchar) AS assignment_group,
		NULL AS category,
	'KM-04' AS 'Flag',
	'Requests completed within two (2) months' AS Name
	FROM metrics.KM_04 c

	UNION

	SELECT c.task AS 'number/task',
			c.sla,
			c.has_breached,
			c.opened_at_date,
			c.closed_at_date,
			ISNULL(c.[service_offering.supported_by],CAST(NULL AS varchar)) AS [service_offering.supported_by],
			c.assignment_group AS assignment_group,
			c.category,
			'KM-07' AS 'Flag',
			'Total Service Desk Incident Resolution Rate' AS Name
		FROM metrics.KM_07 c

	UNION

	SELECT c.task AS 'number/task',
			c.sla,
			c.has_breached,
			c.opened_at_date,
			c.closed_at_date,
			STR(NULL, 25, 5) AS [service_offering.supported_by],
			STR(c.assignment_group, 25, 5) AS assignment_group,
			CAST(NULL AS varchar) AS category,
			'KM-10' AS 'Flag',
			'Soft IMAC completed in time' AS Name
		FROM metrics.KM_10 c

	UNION

	SELECT c.task AS 'number/task',
			c.sla,
			c.has_breached,
			c.opened_at_date,
			c.closed_at_date,
			c.[service_offering.supported_by],
			c.assignment_group,
			c.category,
			'KM-13' AS 'Flag',
			'Workstation break fix time to Resolve (non-Hardware)' AS Name
		FROM metrics.KM_13 c

	UNION

	SELECT c.task AS 'number/task',
			c.sla,
			c.has_breached,
			c.opened_at_date,
			c.closed_at_date,
			c.[service_offering.supported_by],
			c.assignment_group,
			c.category,
			'KM-18' AS 'Flag',
			'Incidents Priority Level 1 + 2 resolved' AS Name
		FROM metrics.KM_18 c

	UNION

	SELECT c.task AS 'number/task',
			c.sla,
			c.has_breached,
			c.opened_at_date,
			c.closed_at_date,
			c.[service_offering.supported_by],
			c.assignment_group,
			c.category,
			'KM-19' AS 'Flag',
			'Incidents Priority Level 3 + 4 resolved' As Name
		FROM metrics.KM_19 c

	UNION

	SELECT c.task AS 'number/task',
			c.sla,
			c.has_breached,
			c.opened_at_date,
			c.closed_at_date,
			c.[service_offering.supported_by],
			c.assignment_group,
			c.category,
			'KM-20' AS 'Flag',
			'Overdue Incidents resolved' As Name
		FROM metrics.KM_20 c 
)x

