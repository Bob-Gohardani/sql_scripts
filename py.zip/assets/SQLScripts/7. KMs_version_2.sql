DROP VIEW IF EXISTS metrics.KM_01;

CREATE VIEW metrics.KM_01
AS
SELECT *,
CONVERT(varchar, i.opened_at, 107) AS opened_at_date,
CONVERT(varchar, i.closed_at, 107) AS closed_at_date
FROM prod.final_incident i
WHERE  i.state = 'Closed'
AND    i.category IN ('Failure', 'Request');

DROP TABLE IF EXISTS metrics.KM_01_formula;

SELECT 'KM-01' AS KM,
	'Service Desk Tickets Escalated to Level 2' AS Name,
	k.opened_at_date,
	k.closed_at_date,
	CAST(k.[caller_id.company.name] AS varchar) AS company,
	CAST(k.location AS varchar)AS site,
	CAST(k.[caller_id.location.country] AS varchar) AS country,
	SUM(CASE WHEN 
	
	((k.opened_by_group_name = 'Service Desk' AND k.assigned_to_group_name = 'Service Desk' 
	AND k.closed_by_group_name = 'Service Desk'AND k.reassignment_count = 0) 
	OR (k.assigned_to_group_name <> 'Service Desk' and k.opened_by_group_name <> 'Service Desk' AND k.closed_by_group_name <> 'Service Desk' ))
	AND k.state = 'Closed'
	AND    k.category IN ('Failure', 'Request')
	
	
	 THEN 1 ELSE 0 END) AS 'formula_part_1',
	COUNT(*) AS 'formula_part_2',
	30.00 AS Expected,
	33.50 AS Minimum,
	CONVERT(date, GETDATE()) AS Report_created_at,
	'The number of tickets that are escalated from the Service Desk to a Level 2 Support Group for resolution.' AS 'Definition',
	0 AS 'empty',
	1 AS 'in_pilot',
	1 AS 'sign_off_by_RWE'
INTO metrics.KM_01_formula
FROM metrics.KM_01 k
GROUP BY k.opened_at_date, k.closed_at_date, k.[caller_id.company.name], k.location, k.[caller_id.location.country];

DROP VIEW IF EXISTS metrics.KM_04;

CREATE VIEW metrics.KM_04
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM input.request_export s -- changed from requested table
WHERE s.state = 'Closed Complete';

DROP TABLE IF EXISTS metrics.KM_04_formula;

IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_04) t) <> 0
	(SELECT 'KM-04' AS CSL,
		'Requests completed within two (2) months' AS Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.[requested_for.company.name] AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.[requested_for.location.country] AS varchar) AS country,
		SUM(CASE
				WHEN (day((closed_at) - (opened_at)) <= 60 ) THEN 1 ELSE 0
			END) AS formula_part_1,	
		COUNT(*) AS formula_part_2,
		100.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'All Requests will be completed within a period of two (2) months.' AS 'Definition',
		0 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.KM_04_formula
	FROM metrics.KM_04 k
GROUP BY k.opened_at_date, k.closed_at_date, k.[requested_for.company.name], k.location, k.[requested_for.location.country])
ELSE
	(SELECT 'KM-04' AS CSL,
		'Requests completed within two (2) months' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'All Requests will be completed within a period of two (2) months.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.KM_04_formula);

DROP VIEW IF EXISTS metrics.KM_07;

CREATE VIEW metrics.KM_07
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC KM-07 Total SD resolution'
	AND s.state = 'Closed'
	AND s.stage = 'Completed';

DROP TABLE IF EXISTS metrics.KM_07_formula;

IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_07) t) <> 0
	(SELECT 'KM-07' AS KM,
		'Total Service Desk Incident Resolution Rate' AS Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Incidents reported to the Service Desk that are resolved by the Service Desk within three (3) Business Days.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.KM_07_formula
	FROM metrics.KM_07 k
GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-07' AS KM,
		'Total Service Desk Incident Resolution Rate' AS Name,
		CAST(NULL AS varchar) AS 'opened_at_date',
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) AS 'company',
		CAST(NULL AS varchar) AS 'site',
		CAST(NULL AS varchar) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Incidents reported to the Service Desk that are resolved by the Service Desk within three (3) Business Days.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.KM_07_formula);

DROP VIEW IF EXISTS metrics.KM_10;

CREATE VIEW metrics.KM_10
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s
WHERE s.sla = 'Infosys EUC KM-10 Soft IMAC'
	AND s.state = 'Closed Complete' 
	AND s.stage = 'Completed';

DROP TABLE IF EXISTS metrics.KM_10_formula;

IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_10) t) <> 0
	(SELECT 'KM-10' AS CSL,
		'Soft IMAC completed in time' AS Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage Soft IMACs successfully completed within two (2) Business Days.' AS 'Definition',
		0 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.KM_10_formula
	FROM metrics.KM_10 k
GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-10' AS CSL,
		'Soft IMAC completed in time' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.0 AS Expected,
		90.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage Soft IMACs successfully completed within two (2) Business Days.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.KM_10_formula);

DROP VIEW IF EXISTS metrics.KM_13;

CREATE VIEW metrics.KM_13
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC KM-13 WS B&F NonHW resol.'
	AND s.state = 'Closed' -- or 'Closed complete' || Need to be clarified
	AND s.stage = 'Completed';

DROP TABLE IF EXISTS metrics.KM_13_formula;

IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_13) t) <> 0
	(SELECT 'KM-13' AS KM,
		'Workstation break fix time to Resolve (non-Hardware)' AS Name, 
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Workstation Break/Fix Incidents successfully resolved within one (1) Business Day.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.KM_13_formula
	FROM metrics.KM_13 k
	GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-13' AS KM,
		'Workstation break fix time to Resolve (non-Hardware)' AS Name, 
		CAST(NULL AS varchar) AS 'opened_at_date',
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) AS 'company',
		CAST(NULL AS varchar) AS 'site',
		CAST(NULL AS varchar) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Workstation Break/Fix Incidents successfully resolved within one (1) Business Day.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.KM_13_formula);

DROP VIEW IF EXISTS metrics.KM_18;

CREATE VIEW metrics.KM_18
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC KM-18 P1&2 resolution'
	AND s.state = 'Closed'
	AND s.stage = 'Completed';

DROP TABLE IF EXISTS metrics.KM_18_formula;

IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_18) t) <> 0
	(SELECT 'KM-18' AS KM, 
		'Incidents Priority Level 1 + 2 resolved' AS Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		100.00 AS Expected,
		95.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of the Incidents Priority Level 1+2 resolved in time.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.KM_18_formula
	FROM metrics.KM_18 k
	GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-18' AS KM, 
		'Incidents Priority Level 1 + 2 resolved' AS Name,
		CAST(NULL AS varchar) AS 'opened_at_date',
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) AS 'company',
		CAST(NULL AS varchar) AS 'site',
		CAST(NULL AS varchar) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.00 AS Expected,
		95.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of the Incidents Priority Level 1+2 resolved in time.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.KM_18_formula);

DROP VIEW IF EXISTS metrics.KM_19;

CREATE VIEW metrics.KM_19
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC KM-19 P3&4 resolution'
	AND s.state = 'Closed'
	AND s.stage = 'Completed';

DROP TABLE IF EXISTS metrics.KM_19_formula;

IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_19) t) <> 0
	(SELECT 'KM-19' AS KM,
		'Incidents Priority Level 3 + 4 resolved' As Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		100.00 AS Expected,
		95.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of the Incidents Priority Level 3+4 resolved in time.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.KM_19_formula
	FROM metrics.KM_19 k
	GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-19' AS KM,
		'Incidents Priority Level 3 + 4 resolved' As Name,
		CAST(NULL AS varchar) AS 'opened_at_date',
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) AS 'company',
		CAST(NULL AS varchar) AS 'site',
		CAST(NULL AS varchar) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.00 AS Expected,
		95.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of the Incidents Priority Level 3+4 resolved in time.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.KM_19_formula);

DROP VIEW IF EXISTS metrics.KM_20;

CREATE VIEW metrics.KM_20
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE task in (SELECT task 
FROM metrics.sla_incident_join s 
WHERE  s.sla = 'Infosys EUC KM-19 P3&4 resolution' AND s.has_breached = 1)
AND sla = 'Infosys EUC KM-20 Overdue Incidents' and  state = 'closed';

DROP TABLE IF EXISTS metrics.KM_20_formula;

SELECT 'KM-20' AS KM, 
                'Overdue Incidents resolved' As Name, 
                k.opened_at AS 'opened_at_date',
                k.closed_at AS 'closed_at_date', 
                CAST(k.company_name AS varchar) AS company, 
                CAST(k.location AS varchar) AS site, 
                CAST(k.location_country AS varchar) AS country, 
                (SELECT COUNT(task) from   metrics.sla_incident_join  t  where 
				task in (SELECT task FROM  metrics.sla_incident_join  s WHERE  s.sla = 'Infosys EUC KM-19 P3&4 resolution' AND s.has_breached = 1) 
                        AND t.sla = 'Infosys EUC KM-20 Overdue Incidents' and t.has_breached = 0
						AND t.opened_at = k.opened_at
						AND t.closed_at = k.closed_at
						AND t.company_name = k.company_name
						AND t.location = k.location
						AND t.location_country = k.location_country
						) AS formula_part_1,

                (SELECT COUNT(task) FROM  metrics.sla_incident_join  s 
                                WHERE  s.sla = 'Infosys EUC KM-19 P3&4 resolution' AND s.has_breached = 1 
								AND s.opened_at = k.opened_at
								AND s.closed_at = k.closed_at
								AND s.company_name = k.company_name
								AND s.location = k.location
								AND s.location_country = k.location_country 
								) AS formula_part_2,  
                100.00 AS Expected, 
                95.00 AS Minimum, 
                CONVERT(date, GETDATE()) AS Report_created_at, 
                'Percentage of the Incidents exceeded 10 (ten) Business Days.' AS 'Definition', 
                0 AS 'empty', 
                1 AS 'in_pilot', 
                1 AS 'sign_off_by_RWE' 
        INTO metrics.KM_20_formula
        FROM metrics.sla_incident_join  k
		WHERE k.state = 'Closed'
		AND k.stage = 'Completed' 
        GROUP BY k.opened_at, k.closed_at, k.company_name, k.location, k.location_country
