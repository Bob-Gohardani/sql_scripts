DROP TABLE IF EXISTS prod.CSL_ALL;

SELECT x.*
INTO prod.CSL_ALL
FROM (

	SELECT * 
	FROM metrics.CSL_01_formula
	UNION
	SELECT * 
	FROM metrics.CSL_02_formula
	UNION
	SELECT *
	FROM metrics.CSL_03_formula
	UNION
	SELECT *
	FROM metrics.CSL_04_formula
	UNION
	SELECT * 
	FROM metrics.CSL_07_formula
	
	UNION
	SELECT 'CSL-08' AS CSL,
		'Workstation Break/Fix Time to Resolve (Hardware)' AS Name,
		CAST(NULL AS varchar) AS 'opened_at_date',
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) AS 'company',
		CAST(NULL AS varchar) AS 'site',
		CAST(NULL AS varchar) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Workstation Break/Fix Incidents successfully resolved within 1 (one) Business Days (end of Next Business Day) for tickets raised before 16:00 Local time. For tickets raised after this the resolution shall be measured at the end of the 3rd working day.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	SELECT * 
	FROM metrics.CSL_09_formula
	UNION
	SELECT * 
	FROM metrics.CSL_10_formula
	UNION
	SELECT * 
	FROM metrics.CSL_11_formula
	UNION
	SELECT * 
	FROM metrics.CSL_13_formula
	UNION
	-- ADDED 22.08.2019 PLACEHOLDER ---------------------------------------
	SELECT 'CSL-06' AS CSL,
		'Completion of replacement of standard IT equipment for Authorized Users ("Hardware as a Service")' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of standard IT equipment replaced within thirty (30) days after Request.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	SELECT 'CSL-16' AS CSL,
		'Agreed corrective actions related to Problems taken in time' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.0 AS Expected,
		80.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of corrective actions related to Problems taken in agreed time.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	SELECT 'CSL-17' AS CSL,
		'Successful complaint ticket closure on time' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.0 AS Expected,
		90.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of successful complaint ticket closure within eight (8) calendar days on average in combination with a maximum number of five (5) complaint backlog tickets (backlog ticket > twenty (20) calendar days).' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	SELECT 'CSL-19' AS CSL,
		'Infrastructure Services Availability' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		99.90 AS Expected,
		99.50 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'This CSL measures the availability of Infrastructure Services during Scheduled Uptime within the Measurement Window. Infrastructure Services will be up and available to the intended Authorized Users and fully functioning as designed during Scheduled Uptime periods within the Measurement Window.This Service Level represents an average Availability for all Infrastructure Services.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	SELECT 'CSL-20' AS CSL,
		'Software Package Completed On-Time' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.0 AS Expected,
		90.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of all Software Packaging Service Requests packaged successfully completed in quality and time.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	SELECT 'CSL-21' AS CSL,
		'Software Distribution � On Time Delivery' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.0 AS Expected,
		90.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The number of successful installations to OS instances through a Software distribution system.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	SELECT 'CSL-22' AS CSL,
		'Patch Distribution � On Time Delivery' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.0 AS Expected,
		90.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Distribute Patches to the OS instances within the agreed upon timeframe.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	) x