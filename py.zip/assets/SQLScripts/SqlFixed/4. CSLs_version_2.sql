-----------------------------------------------  FILTERS CSL-02  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

Update prod.final_incident 
Set reopen_count = 0 
where number = 'INC00013170';

DROP VIEW IF EXISTS metrics.CSL_02;
CREATE VIEW metrics.CSL_02
AS
SELECT *,
	CONVERT(varchar(max), i.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), i.closed_at, 107) AS closed_at_date
FROM prod.final_incident i
WHERE i.opened_by_group_name = 'Service Desk'
	AND i.category IN ('Failure', 'Request')
	AND i.[service_offering.supported_by] IN ('Resolvable by Service Desk', 'Infosys Responsibility')
	AND i.state = 'Closed'
	AND i.assignment_group = 'Service Desk';


----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_02_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_02) t) <> 0
	(SELECT 'CSL-02' AS CSL,
		'Percentage of Incident Records Closed and Not Reopened' AS Name,
		c.opened_at_date,
		c.closed_at_date,
		CAST(c.[caller_id.company.name] AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site, -- CHANGE 12.09.2019 from location.name to location due to laction would be fetch from ether location column from incident or [request.delivery_address] column from request table
		CAST(c.[caller_id.location.country] AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.reopen_count = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.reopen_count) AS formula_part_2,
		98.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Incident Records that are closed and are not reopened within three (3) Business Days.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_02_formula
	FROM metrics.CSL_02 c
	GROUP BY c.opened_at_date, c.closed_at_date, c.[caller_id.company.name], c.location, c.[caller_id.location.country])
ELSE
	(SELECT 'CSL-02' AS CSL,
		'Percentage of Incident Records Closed and Not Reopened' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		98.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Incident Records that are closed and are not reopened within three (3) Business Days.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_02_formula);


-----------------------------------------------  FILTERS CSL-07  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

update metrics.sla_incident_join 
SET has_breached = 0 
where task in ('INC00010981','INC00011177', 'INC00011579', 'INC00011438', 'INC00012458','INC00010893',
'INC00011831','INC00010481','INC00011911','INC00012376','INC00013427','INC00013193','INC00014150','INC00013609',
'INC00013193','INC00014150','INC00013609','INC00015257','INC00013000')

AND sla like ('%CSL-07%'); 

update metrics.sla_incident_join 
SET stage = 'Cancelled'   
where task in ('INC00011229','INC00016790','INC00017181','INC00013936',
'INC00026036','INC00026025','INC00026026','INC00026035','INC00026028','INC00025924','INC00025919','INC00025921','INC00025914',
'INC00025918','INC00025920','INC00025922','INC00025923','INC00025917','INC00026041','INC00026029','INC00026042','INC00026024',
'INC00026020','INC00026040','INC00026037','INC00026039','INC00026038','INC00026027','INC00026043','INC00026044','INC00026015',
'INC00026021','INC00026018','INC00026030','INC00026031','INC00026033','INC00026034','INC00026032','INC00026023','INC00026421',
'INC00026424','INC00026426','INC00026425','INC00026427','INC00026428','INC00026429','INC00026430','INC00026434','INC00026437',
'INC00026440','INC00026443','INC00026445','INC00026432','INC00026441','INC00026781','INC00026438','INC00026435','INC00026792',
'INC00026446','INC00026433','INC00026439','INC00026782','INC00026444','INC00026436','INC00026447','INC00026773',
'INC00026791','INC00026775','INC00026780','INC00026790','INC00026783','INC00026784','INC00026786','INC00026789')
AND sla like ('%CSL-07%');


DROP VIEW IF EXISTS metrics.CSL_07;
CREATE VIEW metrics.CSL_07
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC CSL-07 WS B&F response'
	AND s.state = 'Closed'  -- or "Closed Completed" || Need to be clarified
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_07_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_07) t) <> 0
	(SELECT 'CSL-07' AS CSL,
		'Workstation Break/Fix Time to Respond (Hardware & Non-Hardware)' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstation Break/Fix Incidents responded to within [four (4) hours] during Business Hours.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_07_formula
	FROM metrics.CSL_07 c
GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-07' AS CSL,
		'Workstation Break/Fix Time to Respond (Hardware & Non-Hardware)' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstation Break/Fix Incidents responded to within [four (4) hours] during Business Hours.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_07_formula);


-----------------------------------------------  FILTERS CSL-08  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

DROP VIEW IF EXISTS metrics.CSL_08;
CREATE VIEW metrics.CSL_08
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC CSL-08 WS B&F HW resolution'
	AND s.state = 'Closed' 
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_08_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_08) t) <> 0
	(SELECT 'CSL-08' AS CSL,
		'Workstation Break/Fix Time to Resolve (Hardware)' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Workstation Break/Fix Incidents successfully resolved within 1 (one) Business Days (end of Next Business Day) for tickets raised before 16:00 Local time. For tickets raised after this the resolution shall be measured at the end of the 3rd working day.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.CSL_08_formula
	FROM metrics.CSL_08 c
GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-08' AS CSL,
		'Workstation Break/Fix Time to Resolve (Hardware)' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Workstation Break/Fix Incidents successfully resolved within 1 (one) Business Days (end of Next Business Day) for tickets raised before 16:00 Local time. For tickets raised after this the resolution shall be measured at the end of the 3rd working day.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
		INTO metrics.CSL_08_formula);

-----------------------------------------------  FILTERS CSL-09  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

update metrics.sla_request_join
SET has_breached = 0 
where task in ('RITM0010398','RITM0010455','RITM0010420','RITM0010428','RITM0010494','RITM0011281','RITM0010495','RITM0011272'
,'RITM0011794','RITM0011861','RITM0010629','RITM0012625','RITM0012832','RITM0011641','RITM0011696',
'RITM0013313','RITM0013314','RITM0013315','RITM0013316','RITM0013317','RITM0013318','RITM0013319','RITM0013320','RITM0013321',
'RITM0013322','RITM0013323','RITM0012492',
'RITM0013779','RITM0013780','RITM0011782',
'RITM0013826','RITM0013476','RITM0013478','RITM0013989','RITM0014203','RITM0012493','RITM0014143',
'RITM0014344','RITM0014400','RITM0014401','RITM0013499','RITM0013661' ,
'RITM0014629','RITM0014643','RITM0014568','RITM0014567','RITM0014639','RITM0013860','RITM0013391','RITM0012104',
'RITM0014642','RITM0014641','RITM0014628','RITM0014458',
'RITM0015290','RITM0015392','RITM0015393','RITM0015394','RITM0015395','RITM0015396','RITM0015513',
'RITM0015546','RITM0015453','RITM0013660','RITM0015839','RITM0015828','RITM0015830','RITM0015835','RITM0015837',
'RITM0015840','RITM0015827','RITM0015829','RITM0015836','RITM0015838','RITM0015825','RITM0015826','RITM0015831',
'RITM0015832','RITM0015833','RITM0015834','RITM0016120','RITM0016119','RITM0012229','RITM0015291',
'RITM0016346','RITM0016380','RITM0016349','RITM0016347','RITM0016375')
and sla = 'Infosys EUC CSL-09 Hard IMAC';

DROP VIEW IF EXISTS metrics.CSL_09;
CREATE VIEW metrics.CSL_09
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s
WHERE s.sla = 'Infosys EUC CSL-09 Hard IMAC'
	AND s.state = 'Closed Complete' -- or 'Closed' || Need to be clarified
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_09_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_09) t) <> 0
	(SELECT 'CSL-09' AS CSL,
		'Hard IMAC Completed On-Time' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Measures the percentage of Hard IMACs successfully completed within [three (3)] Business Days' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_09_formula
	FROM metrics.CSL_09 c
	GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-09' AS CSL,
		'Hard IMAC Completed On-Time' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Measures the percentage of Hard IMACs successfully completed within [three (3)] Business Days' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_09_formula);

-----------------------------------------------  FILTERS CSL-10  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

DROP VIEW IF EXISTS metrics.CSL_10;
CREATE VIEW metrics.CSL_10
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s
WHERE s.sla = 'Infosys EUC CSL-10 WS Installation asap'
	AND s.state = 'Closed Complete' -- or 'Closed' || Need to be clarified
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_10_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_10) t) <> 0
	(SELECT 'CSL-10' AS CSL,
		'New Workstation Installation a.s.a.p.' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstations and their related peripheral Equipment and Software successfully installed a.s.a.p. but not later than within one (1) Business Day (end of Next Business Day) for tickets raised before 16:00 Local time. For tickets raised after this the resolution shall be measured at the end of the 3rd working day.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.CSL_10_formula
	FROM metrics.CSL_10 c
	GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-10' AS CSL,
		'New Workstation Installation a.s.a.p.' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstations and their related peripheral Equipment and Software successfully installed a.s.a.p. but not later than within one (1) Business Day (end of Next Business Day) for tickets raised before 16:00 Local time. For tickets raised after this the resolution shall be measured at the end of the 3rd working day.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
		INTO metrics.CSL_10_formula);

-----------------------------------------------  FILTERS CSL-11  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------
update metrics.sla_request_join
SET has_breached = 0 
where task in ('RITM0011312','RITM0011515','RITM0012853','RITM0012850','RITM0012851','RITM0012852','RITM0012599',
'RITM0012622','RITM0012623','RITM0013251','RITM0013305','RITM0013307',
'RITM0012910','RITM0013383','RITM0011098','RITM0014219', 'RITM0012500','RITM0014246','RITM0014817',
'RITM0014498','RITM0015167','RITM0015274','RITM0015114','RITM0013300',
'RITM0015173','RITM0015175','RITM0015174','RITM0015256','RITM0015723')
and sla = 'Infosys EUC CSL-11 WS Installation 2days';

update metrics.sla_request_join
SET Stage = 'Cancelled'
where task in ('RITM0015144','RITM0015512','RITM0015193','RITM0015221','RITM0015391')
and sla = 'Infosys EUC CSL-11 WS Installation 2days';

DROP VIEW IF EXISTS metrics.CSL_11;
CREATE VIEW metrics.CSL_11
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s
WHERE s.sla = 'Infosys EUC CSL-11 WS Installation 2days'
	AND s.state = 'Closed Complete' -- or 'Closed' || Need to be clarified
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_11_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_11) t) <> 0
	(SELECT 'CSL-11' AS CSL,
		'New Workstation Installation within two (2) Business Days' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstations and their related peripheral Equipment and Software successfully installed within two (2) Business Days.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_11_formula
	FROM metrics.CSL_11 c
	GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-11' AS CSL,
		'New Workstation Installation within two (2) Business Days' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstations and their related peripheral Equipment and Software successfully installed within two (2) Business Days.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_11_formula);

-----------------------------------------------  FILTERS CSL-13  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------
update metrics.sla_request_join 
SET has_breached = 0 
where task in ('RITM0013240','RITM0013259','RITM0013262','RITM0013247','RITM0013275','RITM0013239',
'RITM0013229','RITM0013291','RITM0013393','RITM0013394','RITM0013311','RITM0013419','RITM0013649','RITM0013623',
'RITM0013658','RITM0013657','RITM0013842',
'RITM0013280','RITM0013730','RITM0013347','RITM0013621','RITM0013942','RITM0013888','RITM0013909','RITM0013952',
'RITM0014010','RITM0013995','RITM0013956','RITM0013949','RITM0013890','RITM0013369','RITM0013200','RITM0014049',
'RITM0013978','RITM0013855','RITM0014157','RITM0013837',
'RITM0013220','RITM0014001','RITM0014000','RITM0014126','RITM0014236','RITM0014153','RITM0014237','RITM0013898',
'RITM0014181','RITM0013781',
'RITM0013671','RITM0014183','RITM0013854','RITM0014198','RITM0014202','RITM0013927','RITM0014242','RITM0014287',
'RITM0014293','RITM0014301','RITM0014443','RITM0013204','RITM0014244',
'RITM0013702','RITM0014596','RITM0014589','RITM0014590','RITM0014597','RITM0014575','RITM0014707','RITM0014689',
'RITM0014706','RITM0014705','RITM0013630','RITM0013899','RITM0014800','RITM0014579',
'RITM0013872','RITM0014248','RITM0014013','RITM0014299','RITM0014012','RITM0014311','RITM0014850','RITM0013944',
'RITM0014929','RITM0014146','RITM0014866','RITM0013840','RITM0014313','RITM0014355','RITM0014027','RITM0015072',
'RITM0013772','RITM0015137','RITM0015163','RITM0015159','RITM0015223','RITM0015185','RITM0014623','RITM0014314',
'RITM0014444','RITM0013885','RITM0014466','RITM0014330','RITM0014616','RITM0014942','RITM0015273','RITM0015289',
'RITM0015288','RITM0015346','RITM0015352','RITM0015347','RITM0015374','RITM0015376','RITM0015375','RITM0015037',
'RITM0015293','RITM0015475','RITM0015565','RITM0015315','RITM0015359','RITM0015544','RITM0015622','RITM0013217','RITM0015562',
'RITM0016176','RITM0016086','RITM0016100','RITM0015036','RITM0016094','RITM0016138','RITM0016150','RITM0016178',
'RITM0016205','RITM0016203','RITM0016348','RITM0016498','RITM0016522','RITM0016540','RITM0016628''RITM0014610','RITM0016385')
and sla like ('%KM-10%');


DROP VIEW IF EXISTS metrics.CSL_13;
CREATE VIEW metrics.CSL_13
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s														
WHERE (s.sla LIKE '%CSL-06%' or s.sla LIKE '%CSL-09%' OR s.sla LIKE '%CSL-10%' OR s.sla LIKE '%CSL-11%' 
OR s.sla LIKE '%CSL-20%' OR s.sla LIKE '%KM-10%' OR s.sla LIKE '%KM-11%' OR s.sla LIKE '%KM-12%') 
	AND s.state = 'Closed Complete' 
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_13_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_13) t) <> 0
	(SELECT 'CSL-13' AS CSL,
		'Request fulfilment Time' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(*) AS formula_part_2,
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of stated fulfillment times met.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.CSL_13_formula
	FROM metrics.CSL_13 c
	GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-13' AS CSL,
		'Request fulfilment Time' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of stated fulfillment times met.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
		INTO metrics.CSL_13_formula);

-----------------------------------------------  FILTERS CSL-03  -----------------------------------------------
-----------------------------------------------       AVAYA      -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_03_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM input.avaya) a) <> 0
	(SELECT 'CSL-03' AS CSL,
		'Service Desk Speed to Answer' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), a.Date, 107) AS closed_at_date,
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		a.[Split/Skill] as 'country',
		SUM(a.[Calls In SLA]) AS formula_part_1,
		SUM(a.[ACD Calls]) AS formula_part_2,
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The number of calls that are responded to within twenty (20) seconds after the Authorized User selects the option to speak to a Service Desk.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_03_formula
	FROM input.avaya a
	GROUP BY a.Date, a.[Split/Skill])
ELSE
	(SELECT 'CSL-03' AS CSL,
		'Service Desk Speed to Answer' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The number of calls that are responded to within twenty (20) seconds after the Authorized User selects the option to speak to a Service Desk.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_03_formula);

-----------------------------------------------  FILTERS CSL-04  -----------------------------------------------
-----------------------------------------------       AVAYA      -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_04_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM input.avaya) a) <> 0
	(SELECT 'CSL-04' AS CSL,
		'Service Desk Call Abandon Rate' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), a.Date, 107) AS closed_at_date,
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		a.[Split/Skill] as 'country',
		-- SUM(a.[Aban Calls]) AS formula_part_1,
		SUM(a.[Aban Calls]) - (SUM(a.[Aban Calls1]) +  SUM(a.[Aban Calls2]) +  SUM(a.[Aban Calls3]) +  SUM(a.[Aban Calls4])) AS formula_part_1,
		SUM(a.[ACD Calls]) + SUM(a.[Aban Calls]) AS formula_part_2,
		7.00 AS Expected,
		8.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Authorized User Calls that are abandoned after selecting the Voice Response Unit menu item to speak to a Service Desk agent.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_04_formula
	FROM input.avaya a
	GROUP BY a.Date, a.[Split/Skill])
ELSE
	(SELECT 'CSL-04' AS CSL,
		'Service Desk Call Abandon Rate' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		7.00 AS Expected,
		8.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Authorized User Calls that are abandoned after selecting the Voice Response Unit menu item to speak to a Service Desk agent.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_04_formula)

--------------------CSL 01 New (added on 8th June 2020)---------------------


--Wavier Start

update metrics.sla_incident_join 
SET stage = 'Cancelled'
where task in ('INC00034747','INC00034735','INC00034693','INC00034673','INC00034384','INC00034330',
'INC00033058','INC00031834','INC00031458','INC00027803','INC00020337','INC00020159',
'INC00035218','INC00036446','INC00036222','INC00033275')
and sla = 'Infosys EUC CSL-01 First Call Res. 06/20' ;
--Wavier End

DROP VIEW IF EXISTS metrics.CSL_01_6_20;
CREATE VIEW metrics.CSL_01_6_20
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.closed_at >= '2020-07-01 00:00:00.000' and
s.sla = 'Infosys EUC CSL-01 First Call Res. 06/20'
	AND s.state = 'Closed' 
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_01_6_20_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_01_6_20) t) <> 0
	(SELECT 'CSL-01' AS CSL,
		'First call Resolution Rate' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		70.00 AS Expected,
		66.50 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Calls resolved by the Service Desk on the first Call.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_01_6_20_formula
	FROM metrics.CSL_01_6_20 c
GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-01' AS CSL,
		'First call Resolution Rate' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		70.00 AS Expected,
		66.50 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Calls resolved by the Service Desk on the first Call.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_01_6_20_formula);

		DROP TABLE IF EXISTS metrics.CSL_01_formula;
		SELECT x.*
		INTO metrics.CSL_01_formula
		FROM (

				SELECT * 
				FROM metrics.CSL_01_6_20_formula
				UNION
				Select * 
				from metrics.CSL_01_formula_old
			  ) x;
		
		