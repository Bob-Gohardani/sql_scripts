DROP TABLE IF EXISTS metrics.incident_SLA_join;
SELECT s.sla,
	s.sys_id,
	s.has_breached,
	s.stage,
	s.active,
	s.business_duration,
	s.pause_duration,
	s.pause_time,
	i.number,
	i.category,
	i.incident_state,
	i.reopen_count,
	i.subcategory,
	i.service_offering,
	i.[service_offering.support_group],
	i.[service_offering.supported_by],
	i.assignment_group,
	i.contact_type,
	i.opened_at,
	i.closed_at,
	i.state,
	i.priority,
	i.reassignment_count,
	i.[caller_id.company.country] AS 'company_country',
	i.[caller_id.company.name] AS 'company_name',
	i.[caller_id.location.country] AS 'location_country',
	i.location,
	i.opened_by,
	i.opened_by_group_id,
	i.opened_by_group_name,
	i.opened_by_group_u_domain,
	i.closed_by,
	i.closed_by_group_id,
	i.closed_by_group_name,
	i.closed_by_group_u_domain,
	i.assigned_to,
	i.assigned_to_group_id,
	i.assigned_to_group_name,
	i.assigned_to_group_u_domain
INTO metrics.incident_SLA_join
FROM prod.final_incident i
LEFT JOIN input.sla s ON s.task = i.number;


-- ADDING INC00011378

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution', -- sla
'INC00011378', -- number
'Altenessener Str. 27-33, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-18 15:49:22.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-11 15:00:09.000', 121), -- closed_at
'Request', -- category
'Phone', -- contact_type
'Closed', -- state
'Resolvable by Service Desk', -- [service_offering.supported_by]
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);

-- ADDING INC00011533 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00011533',
'Electron, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB',
'Completed',
0,
'RWE NPOWER PLC (Generation)',
'GB',
CONVERT(DATETIME, '2019-11-20 12:03:51.000', 121),
CONVERT(DATETIME, '2019-12-10 17:00:00.000', 121),
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);

-- ADDING INC00012149 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain

)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012149', -- number
'60 Threadneedle Street, EC2R 8HP, London, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-11-27 11:16:20.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-11 17:00:04.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);

-- ADDING INC00012250 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012250', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-28 10:06:50.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-08 14:00:02.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);

-- ADDING INC00012317 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012317', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-11-28 17:51:34.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-08 15:00:01.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012337 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012337', -- number
'Altenessener Str. 27-33, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-29 09:38:52.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-07 13:00:08.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);

-- ADDING INC00012522 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012522', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-03 08:41:57.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-09 14:00:11.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);


-- ADDING INC00012533 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012533', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-12-03 09:57:44.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-08 12:00:02.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012562 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012562', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-03 11:30:35.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-10 18:00:02.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Hypercare', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012677 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012677', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-04 09:10:14.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-11 10:00:13.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012717 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012717', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-04 11:57:44.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-09 13:00:10.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012742 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012742', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-04 14:12:54.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-09 15:00:08.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012743 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012743', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-04 14:20:23.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-11 15:00:08.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);


-- ADDING INC00012745 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012745', -- number
'Ernestinenstr. 60, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-04 14:23:26.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-09 16:00:02.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);

-- ADDING INC00012758 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012758', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-04 15:18:21.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-11 15:00:11.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);

-- ADDING INC00012788 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012788', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-05 08:45:54.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-11 13:00:09.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);

-- ADDING INC00012864 --

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012864', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-05 15:48:26.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-10 17:00:01.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Hypercare', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012899 --
 
 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012899', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-06 09:38:29.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-11 14:00:11.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);
---------------- ADDED ON 20.12.2019 ----------------
-- ADDING INC00011511

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00011511', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-20 10:28:26.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-15 17:00:03.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);

-- ADDING INC00012121

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012121', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-27 08:09:08.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-14 15:00:08.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Hypercare', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012143

 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012143', -- number
'60 Threadneedle Street, EC2R 8HP, London, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-11-27 11:04:38.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-14 15:00:16.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012228

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012228', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-28 08:49:17.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-16 10:00:07.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012857

 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012857', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-05 15:02:57.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-16 11:00:07.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012994

 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012994', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-09 07:42:06.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-14 10:00:04.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Desktop Support Essen_Altenessener Str.27', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00012995

 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012995', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-09 07:48:49.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-18 14:00:05.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
)

-- ADDING INC00013014

 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013014', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-09 09:09:11.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-15 17:00:05.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);

-- ADDING INC00013026

 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013026', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-09 10:00:47.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-17 09:00:03.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Active_Directory_Group', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013038

 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013038', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-09 10:37:39.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-17 13:00:07.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
NULL, -- closed_by_group_name
NULL, -- closed_by_group_u_domain
NULL, -- assigned_to_group_name
NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013183

 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013183', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-10 10:53:32.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-16 15:00:04.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);

-- ADDING INC00013286

 INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013286', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-11 08:36:07.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-17 15:00:06.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Hypercare', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
 NULL, -- closed_by_group_name
 NULL, -- closed_by_group_u_domain
 NULL, -- assigned_to_group_name
 NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013293

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013293', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-11 08:56:00.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-16 10:00:09.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
 NULL, -- closed_by_group_name
 NULL, -- closed_by_group_u_domain
 NULL, -- assigned_to_group_name
 NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013296

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013296', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-11 09:15:11.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-18 08:00:06.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
 NULL, -- closed_by_group_name
 NULL, -- closed_by_group_u_domain
 NULL, -- assigned_to_group_name
 NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013413

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013413', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-12 08:01:56.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-17 15:00:07.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
 NULL, -- closed_by_group_name
 NULL, -- closed_by_group_u_domain
 NULL, -- assigned_to_group_name
 NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013444

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013444', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-12 10:16:42.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-18 13:00:04.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'FS_DE_K�ln', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
 NULL, -- closed_by_group_name
 NULL, -- closed_by_group_u_domain
 NULL, -- assigned_to_group_name
 NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013445

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013445', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-12 10:22:47.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-18 10:00:06.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);

-- ADDING INC00013462

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013462', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-12 10:57:58.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-18 12:00:11.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'FS_DE_K�ln', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
 NULL, -- closed_by_group_name
 NULL, -- closed_by_group_u_domain
 NULL, -- assigned_to_group_name
 NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013496

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013496', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-12 13:01:55.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-17 14:00:07.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
 'Service Desk', -- closed_by_group_name
 'Infosys', -- closed_by_group_u_domain
 NULL, -- assigned_to_group_name
 NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013504

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013504', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-12-12 13:46:17.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-18 12:00:10.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group

'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain

 'Service Desk', -- closed_by_group_name
 'Infosys', -- closed_by_group_u_domain

 'Service Desk', -- assigned_to_group_name
 'Infosys' -- assigned_to_group_u_domain
);

-- ADDING INC00013603

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013603', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-13 11:18:51.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-18 12:00:14.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Hypercare', -- assignment_group

'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain

 NULL, -- closed_by_group_name
 NULL, -- closed_by_group_u_domain

 NULL, -- assigned_to_group_name
 NULL -- assigned_to_group_u_domain
);

-- ADDING INC00013613

INSERT INTO metrics.incident_SLA_join (sla, 
										number, 
										location, 
										stage, 
										has_breached, 
										company_name, 
										location_country, 
										opened_at, 
										closed_at, 
										category, 
										contact_type, 
										state,
										[service_offering.supported_by],
										-- NEW --
										incident_state,
										assignment_group,
										opened_by_group_name,
										opened_by_group_u_domain,
										closed_by_group_name,
										closed_by_group_u_domain,
										assigned_to_group_name,
										assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013613', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-13 12:54:40.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-18 14:00:07.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group

'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain

 'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain

 NULL, -- assigned_to_group_name
 NULL -- assigned_to_group_u_domain
);


-- 31/12/2019

--Adding  INC00012633

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012633', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-03 16:24:31.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-25 18:00:02.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);

--Adding  INC00013193

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013193', -- number
'Rellinghauser Str. 31, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
Null, -- location_country
CONVERT(DATETIME, '2019-12-10 11:21:08.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-23 12:00:05.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);


--Adding  INC00013695

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013695', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-16 10:52:35.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-21 12:00:05.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);

--Adding  INC00013761

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013761', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-16 16:01:29.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-25 13:00:08.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Active_Directory_Group', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


--Adding  INC00013819

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013819', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-17 11:07:41.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-22 12:00:09.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);

--Adding  INC00013835

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013835', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-12-17 12:25:23.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-23 12:00:03.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


--Adding  INC00013854

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013854', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-17 13:10:01.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-22 14:00:07.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


--Adding  INC00013930

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013930', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-18 09:57:15.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-25 18:00:04.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);


--Adding  INC00013937

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013937', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-18 10:17:52.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-28 11:00:01.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
Null, -- closed_by_group_name
Null, -- closed_by_group_u_domain
Null, -- assigned_to_group_name
Null -- assigned_to_group_u_domain
);


--Adding  INC00013967

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013967', -- number
'Altenessener Str. 35, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-18 12:34:31.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-25 15:00:08.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
Null, -- closed_by_group_name
Null, -- closed_by_group_u_domain
Null, -- assigned_to_group_name
Null -- assigned_to_group_u_domain
);

--Adding  INC00013989

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013989', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-18 14:06:25.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-23 17:00:06.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
Null, -- closed_by_group_name
Null, -- closed_by_group_u_domain
Null, -- assigned_to_group_name
Null -- assigned_to_group_u_domain
);

--Adding  INC00014030

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014030', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-19 08:26:04.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-24 12:00:07.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
Null, -- closed_by_group_name
Null, -- closed_by_group_u_domain
Null, -- assigned_to_group_name
Null -- assigned_to_group_u_domain
);


--Adding  INC00014036

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014036', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Nuclear GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-19 08:44:53.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-24 16:00:05.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
Null, -- closed_by_group_name
Null, -- closed_by_group_u_domain
Null, -- assigned_to_group_name
Null -- assigned_to_group_u_domain
);

--Adding  INC00014040

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014040', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-19 09:02:08.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-24 10:00:03.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
Null, -- assigned_to_group_name
Null -- assigned_to_group_u_domain
);

-- Adding INC00014050

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014050', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-19 10:03:09.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-25 12:00:09.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'FS_DE_K�ln', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
Null, -- closed_by_group_name
Null, -- closed_by_group_u_domain
Null, -- assigned_to_group_name
Null -- assigned_to_group_u_domain
);


-- Adding INC00014206

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014206', -- number
'Altenessener Str. 27-33, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-20 15:26:48.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-28 11:00:02.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport
EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
Null, -- closed_by_group_name
Null, -- closed_by_group_u_domain
Null, -- assigned_to_group_name
Null -- assigned_to_group_u_domain
);

-- Adding INC00011472

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00011472', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-19 16:34:45.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-04 15:00:11.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);

-- Adding INC00011860

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00011860', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-25 09:58:48.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-04 10:00:06.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'HR Successfactors', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
Null, -- closed_by_group_name
Null, -- closed_by_group_u_domain
Null, -- assigned_to_group_name
Null -- assigned_to_group_u_domain
);


-- Adding INC00012132

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012132', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-27 09:58:43.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-02 13:00:04.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);


-- Adding INC00012133

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012133', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-27 10:00:31.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-04 15:00:11.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);


-- Adding INC00012147

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012147', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-11-27 11:13:50.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-02 12:00:00.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


-- Adding INC00012216

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012216', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-27 23:06:10.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-28 16:00:04.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


-- Adding INC00012300

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012300', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-11-28 15:03:35.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-03 16:00:04.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


-- Adding INC00012302

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012302', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-11-28 15:12:23.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-03 16:00:03.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


-- Adding INC00012333

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00012333', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-29 09:25:42.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-04 10:00:05.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


-- Adding INC00013152

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013152', -- number
'60 Threadneedle Street, EC2R 8HP, London, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-12-10 08:40:23.000', 121), -- opened_at
CONVERT(DATETIME, '2019-12-21 16:00:06.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


-- Updating  INC00013867

update metrics.incident_SLA_join 
SET has_breached = 0 
where number in ('INC00013867') 
AND sla like ('%CSL-01%');

--Added on 13/01/2019


-- Adding INC00011075


INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00011075', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-06 10:23:46.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-12 15:00:04.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);


--Adding INC00011783

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00011783', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-11-22 13:25:44.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-01 09:00:05.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);


--Adding INC00013394

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013394', -- number
'Helenenstra�e 146, 45143, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-11 15:43:44.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-08 14:00:09.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Desktop Support Essen_TradingFloor Essen', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);

--Adding INC00014045

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014045', -- number
'Altenessener Str. 27-33, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-19 09:41:09.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-12 20:00:02.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'License Management', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null -- assigned_to_group_u_domain
);

--Adding INC00014057

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014057', -- number
'Am Kraftwerk 17, 52249, Eschweiler, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-19 10:29:08.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-05 10:00:01.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys' -- assigned_to_group_u_domain
);


--Adding INC00014378

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014378', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-02 12:51:42.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-07 14:00:02.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00014468

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014468', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-06 08:15:01.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-11 14:00:05.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00014538

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014538', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-06 11:42:32.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-11 16:00:05.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);

--Added on 21/01/2019

--Adding INC00013621

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013621', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-13 13:42:51.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-13 16:00:12.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'FS_DE_Essen-Huyssenallee', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);

--Adding INC00014168

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014168', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-20 10:14:23.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 16:00:12.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00014741

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014741', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Nuclear GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-07 12:53:51.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-13 13:00:06.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);

--Adding INC00014932

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014932', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-08 14:07:30.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-13 16:00:07.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00014108

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014108', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-19 14:26:27.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 14:00:07.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);

--Adding INC00010855

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00010855', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-10-24 14:28:20.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-13 17:00:05.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Hypercare', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);

--Adding INC00013679

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013679', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-16 09:48:12.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-13 18:00:07.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Security Mgmt', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00014188

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014188', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-12-20 12:20:10.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 14:00:06.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);


--Adding INC00014537

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014537', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE NPOWER PLC (Generation)', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2020-01-06 11:41:17.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 14:00:12.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);



--Adding INC00014658

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014658', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-07 09:13:17.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 14:00:06.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);


--Adding INC00014589

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014589', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-06 14:20:37.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-19 15:00:03.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'FS_DE_Essen-Huyssenallee', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00015282

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015282', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-13 08:59:38.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-19 14:00:00.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015308

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015308', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-13 10:24:13.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 13:00:04.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Updating INC00014556

Update metrics.incident_SLA_join
Set has_breached = '0' where number = 'INC00014556'
and sla = 'Infosys EUC CSL-01 First Call Resolution';


--Adding INC00015176

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015176', -- number
'Oak House, 1 Bridgwater Road, WR4 9FP, Worcester, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE NPOWER PLC (Generation)', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2020-01-10 10:52:51.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 14:00:10.000', 121), -- closed_at
'Failure',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);



--Adding INC00014173

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014173', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading UK', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-12-20 10:48:52.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-19 12:00:05.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Desktop Support Swindon', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00015140

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015140', -- number
'Altenessener Str. 27-33, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-10 08:33:02.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-15 11:00:01.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Desktop Support Essen_Altenessener Str.27', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015086

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015086', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Nuclear GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-09 14:51:47.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 12:00:10.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'SAP MM-PUR', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015113

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015113', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'RWE NPOWER PLC (Generation)', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2020-01-09 17:12:08.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-14 19:00:01.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Desktop Support Swindon', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015324

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015324', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-13 11:10:25.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-19 12:00:08.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);


--Adding INC00014421

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014421', -- number
'Helenenstra�e 149, 45143, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-03 10:35:53.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-14 14:00:06.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Infra Packaging', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);




--Adding INC00015510

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015510', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-14 14:08:37.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-19 16:00:02.000', 121), -- closed_at
'Request',
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00014849

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014849', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-08 09:01:10.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-13 10:00:06.000', 121), -- closed_at
'Failure',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);





--Adding INC00015327

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015327', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-13 11:14:59.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 12:00:11.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015376

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015376', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-13 14:18:37.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 15:00:02.000', 121), -- closed_at
'Failure',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015383

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015383', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-13 14:26:09.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-18 15:00:03.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015445

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015445', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-14 09:44:53.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-19 11:00:10.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


-- Updating INC00013021  & INC00014730

Update metrics.incident_SLA_join
set stage = 'Completed' 
where number in ('INC00013021' , 'INC00014730' ) 
and sla = 'Infosys EUC CSL-01 First Call Resolution';

--added on 28/01/2019

--Adding INC00013825

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00013825', -- number
'Trigonos, Windmill Hill Business Park, Whitehill Way, SN5 6PB, Swindon, GB', -- location
'Completed', -- stage
0, -- has_breached
'Trading Swindon', -- company_name
'GB', -- location_country
CONVERT(DATETIME, '2019-12-17 11:33:33.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-22 16:00:11.000', 121), -- closed_at
'Failure',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Security Mgmt', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);

--Adding INC00014984

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00014984', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-08 17:06:47.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-25 09:00:03.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00015058

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015058', -- number
'Helenenstra�e 146, 45143, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-09 12:50:32.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-26 14:00:09.000', 121), -- closed_at
'Failure',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00015104

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015104', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-09 16:12:15.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-26 12:00:06.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Desktop Support Essen_Altenessener Str.27', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00015316

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015316', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-13 10:40:51.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-25 14:00:04.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Desktop Support Essen_Altenessener Str.27', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);


--Adding INC00015601

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015601', -- number
'Helenenstra�e 149, 45143, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-15 08:42:18.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-20 10:00:05.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015619

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015619', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-15 09:17:32.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-26 11:00:04.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015624

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015624', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-15 09:27:04.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-26 16:00:03.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'EUC_RemoteSupport', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);



--Adding INC00015676

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015676', -- number
'St�ttgenweg 2, 50935, K�ln, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-15 12:48:42.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-21 19:00:03.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);


--Adding INC00015775

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015775', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Generation SE', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-16 10:46:42.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-21 15:00:00.000', 121), -- closed_at
'Request',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);


--Adding INC00015810

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00015810', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-16 12:41:38.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-21 15:00:00.000', 121), -- closed_at
'Failure',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
'Service Desk', -- assigned_to_group_name
'Infosys'-- assigned_to_group_u_domain
);




--Adding INC00016091

INSERT INTO metrics.incident_SLA_join (sla, 
number, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC CSL-01 First Call Resolution',
'INC00016091', -- number
'Huyssenallee 2, 45128, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Power AG', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2020-01-20 15:58:54.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-25 17:00:03.000', 121), -- closed_at
'Request',  
'Chat',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Service Desk', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
'Service Desk', -- closed_by_group_name
'Infosys', -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
);







