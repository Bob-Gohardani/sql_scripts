DROP TABLE IF EXISTS prod.CSL_with_incidents;

SELECT x.*
INTO prod.CSL_with_incidents
FROM (
	SELECT c.number AS 'number/task',
	c.sla,
	c.has_breached,
	c.opened_at_date,
	c.closed_at_date,
	NULL as [service_offering.supported_by],
	NULL as assignment_group,
	NULL as category,
	'CSL-01' AS 'Flag',
	'First call Resolution Rate' AS Name
	FROM metrics.CSL_01 c

	UNION

	SELECT c.number AS 'number/task',
	NULL AS 'sla',
	NULL AS 'has_breached',
	c.opened_at_date,
	c.closed_at_date,
	c.[service_offering.supported_by],
	c.assignment_group,
	c.category,
	'CSL-02' AS 'Flag',
	'Percentage of Incident Records Closed and Not Reopened' AS Name
	FROM metrics.CSL_02 c

	UNION

	SELECT c.task AS 'number/task',
	c.sla,
	c.has_breached,
	c.opened_at_date,
	c.closed_at_date,
	c.[service_offering.supported_by],
	c.assignment_group,
	c.category,
	'CSL-07' AS 'Flag',
	'Workstation Break/Fix Time to Respond (Hardware & Non-Hardware)' AS Name
	FROM metrics.CSL_07 c

	UNION

	SELECT c.task AS 'number/task',
	c.sla,
	c.has_breached,
	c.opened_at_date,
	c.closed_at_date,
	STR(NULL, 25, 5) as [service_offering.supported_by],
	STR(c.assignment_group, 25, 5) AS assignment_group,
	STR(NULL, 25, 5) as 'category',
	'CSL-09' AS 'Flag',
	'Hard IMAC Completed On-Time' AS Name
	FROM metrics.CSL_09 c

	UNION

	SELECT c.task AS 'number/task',
	c.sla,
	c.has_breached,
	c.opened_at_date,
	c.closed_at_date,
	NULL as [service_offering.supported_by],
	STR(c.assignment_group, 25, 5) AS assignment_group,
	NULL as 'category',
	'CSL-10' AS 'Flag',
	'New Workstation Installation a.s.a.p.' AS Name
	FROM metrics.CSL_10 c

	UNION

	SELECT  c.task AS 'number/task',
	c.sla,
	c.has_breached,
	c.opened_at_date,
	c.closed_at_date,
	NULL as [service_offering.supported_by],
	STR(c.assignment_group, 25, 5) AS assignment_group,
	NULL as 'category',
	'CSL-11' AS 'Flag',
	'New Workstation Installation within two (2) Business Days' AS Name
	FROM metrics.CSL_11 c

	UNION

	SELECT NULL AS 'number/task',
		NULL AS sla,
		NULL AS has_breached,
		NULL AS opened_at_date,
		NULL AS closed_at_date,
		NULL AS [service_offering.supported_by],
		STR(NULL, 25, 5) AS assignment_group,
		NULL AS category,
		'CSL-13' AS 'Flag',
		'Request fulfilment Time' AS Name
) x;



