-- KM 01 -- Old Formula -- 

/*DROP VIEW IF EXISTS metrics.KM_01;
CREATE VIEW metrics.KM_01
AS
SELECT *,
CONVERT(varchar, i.opened_at, 107) AS opened_at_date,
CONVERT(varchar, i.closed_at, 107) AS closed_at_date
FROM prod.final_incident i
WHERE  i.state = 'Closed'
AND    i.category IN ('Failure', 'Request')
AND i.closed_at  <= '2020-06-01 00:00:00.000'*/
-----------------------------------------------  FORMULA ----------------------------------------------

/*
DROP TABLE IF EXISTS metrics.KM_01_formula_old; --dropping the old table & creating new with the name of km_01_formula_old
SELECT 'KM-01' AS KM,
	'Service Desk Tickets Escalated to Level 2' AS Name,
	k.opened_at_date,
	k.closed_at_date,
	CAST(k.[caller_id.company.name] AS varchar) AS company,
	CAST(k.location AS varchar)AS site,
	CAST(k.[caller_id.location.country] AS varchar) AS country,
	SUM(CASE WHEN 
	
	((k.opened_by_group_name = 'Service Desk' AND k.assigned_to_group_name = 'Service Desk' 
	AND k.closed_by_group_name = 'Service Desk'AND k.reassignment_count = 0) 
	OR (k.assigned_to_group_name <> 'Service Desk' and k.opened_by_group_name <> 'Service Desk' AND k.closed_by_group_name <> 'Service Desk' ))
	AND k.state = 'Closed'
	AND    k.category IN ('Failure', 'Request')
	
	
	 THEN 1 ELSE 0 END) AS 'formula_part_1',
	COUNT(*) AS 'formula_part_2',
	30.00 AS Expected,
	33.50 AS Minimum,
	cast(null as datetime) AS Report_created_at,
	'The number of tickets that are escalated from the Service Desk to a Level 2 Support Group for resolution.' AS 'Definition',
	0 AS 'empty',
	1 AS 'in_pilot',
	1 AS 'sign_off_by_RWE'
INTO metrics.KM_01_formula_old
FROM metrics.KM_01 k
GROUP BY k.opened_at_date, k.closed_at_date, k.[caller_id.company.name], k.location, k.[caller_id.location.country]; */

-----------------------------------------------  FILTERS KM - 04  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

DROP VIEW IF EXISTS metrics.KM_04;
CREATE VIEW metrics.KM_04
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM input.request_export s -- changed from requested table
WHERE s.state = 'Closed Complete';

-----------------------------------------------  FORMULA ----------------------------------------------
DROP TABLE IF EXISTS metrics.KM_04_formula
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_04) t) <> 0
	(SELECT 'KM-04' AS CSL,
		'Requests completed within two (2) months' AS Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.[requested_for.company.name] AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.[requested_for.location.country] AS varchar) AS country,
		SUM(CASE
				WHEN (day((closed_at) - (opened_at)) <= 60 ) THEN 1 ELSE 0
			END) AS formula_part_1,	
		COUNT(*) AS formula_part_2,
		100.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'All Requests will be completed within a period of two (2) months.' AS 'Definition',
		0 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.KM_04_formula
	FROM metrics.KM_04 k
GROUP BY k.opened_at_date, k.closed_at_date, k.[requested_for.company.name], k.location, k.[requested_for.location.country])
ELSE
	(SELECT 'KM-04' AS CSL,
		'Requests completed within two (2) months' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'All Requests will be completed within a period of two (2) months.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.KM_04_formula);


-----------------------------------------------  FILTERS KM - 07  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------
update metrics.sla_incident_join
SET has_breached = 0 
where task in ('INC00015744')
and sla = 'Infosys EUC KM-07 Total SD resolution';

update metrics.sla_incident_join
SET Stage = 'Cancelled'	
where task in ('INC00022688')
and sla = 'Infosys EUC KM-07 Total SD resolution';

DROP VIEW IF EXISTS metrics.KM_07;
CREATE VIEW metrics.KM_07
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC KM-07 Total SD resolution'
	AND s.state = 'Closed'
	AND s.stage = 'Completed';

-----------------------------------------------  FORMULA ----------------------------------------------

DROP TABLE IF EXISTS metrics.KM_07_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_07) t) <> 0
	(SELECT 'KM-07' AS KM,
		'Total Service Desk Incident Resolution Rate' AS Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Incidents reported to the Service Desk that are resolved by the Service Desk within three (3) Business Days.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.KM_07_formula
	FROM metrics.KM_07 k
GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-07' AS KM,
		'Total Service Desk Incident Resolution Rate' AS Name,
		CAST(NULL AS varchar) AS 'opened_at_date',
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) AS 'company',
		CAST(NULL AS varchar) AS 'site',
		CAST(NULL AS varchar) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Incidents reported to the Service Desk that are resolved by the Service Desk within three (3) Business Days.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.KM_07_formula);


-----------------------------------------------  FILTERS KM - 10  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------



DROP VIEW IF EXISTS metrics.KM_10;
CREATE VIEW metrics.KM_10
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s
WHERE s.sla = 'Infosys EUC KM-10 Soft IMAC'
	AND s.state = 'Closed Complete' 
	AND s.stage = 'Completed';

-----------------------------------------------  FORMULA ----------------------------------------------

DROP TABLE IF EXISTS metrics.KM_10_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_10) t) <> 0
	(SELECT 'KM-10' AS CSL,
		'Soft IMAC completed in time' AS Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage Soft IMACs successfully completed within two (2) Business Days.' AS 'Definition',
		0 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.KM_10_formula
	FROM metrics.KM_10 k
GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-10' AS CSL,
		'Soft IMAC completed in time' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.0 AS Expected,
		90.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage Soft IMACs successfully completed within two (2) Business Days.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.KM_10_formula);

-----------------------------------------------  FILTERS KM - 13  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

update metrics.sla_incident_join 
SET has_breached = 0 
where task in ('INC00012094','INC00012746','INC00012928','INC00013389','INC00013787','INC00014045',
'INC00015104','INC00015316','INC00013825','INC00014684','INC00015336','INC00015399',	
'INC00015987','INC00011229','INC00013837','INC00014197','INC00014677','INC00014894','INC00015453','INC00015676',
'INC00015072','INC00015499','INC00015868','INC00016047','INC00013964','INC00014046','INC00015354',
'INC00017343','INC00016407','INC00016971','INC00016267','INC00016305','INC00015604',
'INC00016956','INC00017814','INC00017048','INC00017228','INC00016751','INC00012638',
'INC00012716','INC00016036','INC00012305','INC00012913','INC00015645','INC00016790','INC00016110','INC00016936',
'INC00013905','INC00011385','INC00014663','INC00016637','INC00016676','INC00016882','INC00016197','INC00015960',
'INC00017085','INC00013390','INC00013936','INC00016283','INC00014048','INC00015108','INC00013392','INC00015518',
'INC00016862','INC00011143','INC00013132','INC00014151','INC00014314','INC00014542','INC00014848','INC00015144',
'INC00015435','INC00015448','INC00015482','INC00015751','INC00016150','INC00016393','INC00016401','INC00016414',
'INC00016574','INC00016702','INC00016836','INC00016871','INC00016965','INC00017146','INC00017219','INC00017277',
'INC00017523','INC00017530','INC00017552','INC00017580','INC00017625','INC00017849','INC00018159','INC00018567',
'INC00013607','INC00018734','INC00017723','INC00018145','INC00018555','INC00019001','INC00018933','INC00019027',
'INC00017551','INC00014712','INC00017893','INC00018128','INC00018296','INC00014681','INC00017805','INC00014955',
'INC00017414','INC00019179','INC00018894','INC00018440','INC00015981','INC00014132','INC00015185','INC00017179',
'INC00016161','INC00017548','INC00018131','INC00011089','INC00011170','INC00014220','INC00019955','INC00018524',
'INC00018642','INC00018653','INC00018513','INC00018858','INC00018882','INC00018906','INC00017100','INC00019514',
'INC00019650','INC00019936','INC00019966','INC00020219','INC00020352','INC00018683','INC00018691','INC00019248',
'INC00019625','INC00020058','INC00016730','INC00019930','INC00020386','INC00020067','INC00019042','INC00017612',
'INC00020762','INC00020267','INC00020524','INC00020348','INC00020645','INC00017971','INC00019962','INC00020704',
'INC00021126','INC00020873','INC00020578','INC00020241','INC00020797','INC00020174','INC00019938','INC00020390',
'INC00016889','INC00020230','INC00020330','INC00019919','INC00019563','INC00020708',
'INC00021087','INC00019495','INC00021395','INC00020642','INC00021128','INC00021119','INC00015592','INC00018171',
'INC00017036','INC00021616','INC00021290','INC00013891','INC00017861','INC00017587','INC00017639','INC00021402',
'INC00019052','INC00019212','INC00021373','INC00020764','INC00021572','INC00021617','INC00021605','INC00018701',
'INC00019515','INC00021751','INC00021920','INC00016865','INC00021767','INC00021954','INC00021803','INC00021805',
'INC00021826','INC00021859','INC00021886','INC00021508','INC00020478','INC00021647','INC00022005','INC00019840',
'INC00022267','INC00021761','INC00021142','INC00019245','INC00021821','INC00022167','INC00022308',
'INC00022642','INC00020604','INC00022770','INC00017618','INC00019896','INC00021663','INC00019391','INC00022307',
'INC00021219','INC00022554','INC00021897','INC00022810','INC00022829','INC00022625','INC00019550','INC00020339',
'INC00019668','INC00019369','INC00019855','INC00021027','INC00022787','INC00022088','INC00021502','INC00021331',
'INC00022564','INC00011723','INC00011608','INC00022989','INC00018506','INC00021306','INC00021787','INC00021165',
'INC00020776','INC00020547','INC00023014','INC00023141','INC00022593','INC00022779','INC00013934',
'INC00017917','INC00020493','INC00020880','INC00021297','INC00021464','INC00021776','INC00021817',
'INC00023001','INC00023095','INC00023110','INC00022630','INC00021837','INC00023158','INC00020135',
'INC00021876','INC00022950','INC00023475',
'INC00020130','INC00020416','INC00020734','INC00020968','INC00020971','INC00021144','INC00022048','INC00022054',
'INC00020098','INC00022276','INC00023324','INC00024119','INC00021554','INC00021990','INC00014669','INC00024111',
'INC00024245','INC00024109','INC00023728','INC00023904','INC00022271',
'INC00020388','INC00022825','INC00021192','INC00024462','INC00024547','INC00024592','INC00024172','INC00024574',
'INC00023831','INC00024743','INC00024531','INC00021823','INC00023395','INC00024915','INC00024989','INC00024510',
'INC00024468','INC00024720','INC00023423','INC00025205','INC00024273','INC00013701','INC00021298','INC00023693',
'INC00023949','INC00025008','INC00024087','INC00023665','INC00025301','INC00025605',
'INC00025337','INC00024506','INC00021675','INC00022318','INC00022700','INC00023907','INC00025899','INC00024476',
'INC00025272','INC00024535','INC00024624','INC00024992','INC00025082',
'INC00020937','INC00022574','INC00016067','INC00025714','INC00024640','INC00025108','INC00025118',
'INC00025808','INC00026405','INC00023207','INC00023756','INC00021524','INC00022476','INC00026379',
'INC00026541','INC00025938','INC00026179','INC00023994','INC00026121','INC00026777','INC00026603',
'INC00023027','INC00020811','INC00025861','INC00026268','INC00026175','INC00026714','INC00023200',
'INC00025567','INC00025865',
'INC00024964','INC00027101','INC00026136','INC00026918','INC00024608','INC00026822','INC00023108',
'INC00026995','INC00023470','INC00022294','INC00026819','INC00023821','INC00026528','INC00026772',
'INC00016021','INC00026741','INC00021344','INC00025936','INC00024752','INC00026986','INC00027867',
'INC00026393','INC00027665','INC00025513','INC00022123','INC00026693','INC00027914','INC00022834','INC00017432',
'INC00023256','INC00027534','INC00024224','INC00028097','INC00023263','INC00027577','INC00027436','INC00018788',
'INC00026533','INC00028282','INC00027745','INC00027566','INC00027735','INC00027747','INC00022277','INC00028356',
'INC00028638','INC00027205','INC00026954','INC00027428','INC00028547','INC00022897','INC00026942','INC00027711',
'INC00026863','INC00028574','INC00028274','INC00029212','INC00028132','INC00029476','INC00028709','INC00027293',
'INC00029468','INC00028479','INC00029054','INC00029039','INC00029218','INC00029252','INC00024240','INC00029451',
'INC00029523','INC00028490','INC00029660','INC00029629','INC00024896','INC00029879','INC00029676','INC00029235','INC00028143',
'INC00028716','INC00030392','INC00028998','INC00029160','INC00029470','INC00029648','INC00027292','INC00028043','INC00030195',
'INC00029174','INC00022424','INC00029657','INC00028182','INC00028705','INC00029734','INC00030991','INC00030902','INC00031130',
'INC00030333','INC00030145','INC00029808','INC00030658','INC00025515','INC00027609','INC00025574','INC00025097','INC00029375',
'INC00029410','INC00027478','INC00029696','INC00030613','INC00031024','INC00023367','INC00031357','INC00032026','INC00030139',
'INC00030587','INC00029080','INC00030395','INC00029134','INC00030540','INC00031226','INC00032547','INC00029380','INC00032543',
'INC00032224','INC00029685','INC00032634','INC00032043','INC00026659','INC00028318','INC00032217','INC00031925','INC00032942',
'INC00033110','INC00032763','INC00025483','INC00032657','INC00031849','INC00029736','INC00030388','INC00020860','INC00027912',
'INC00029755','INC00023281','INC00032296','INC00031137','INC00033253','INC00033572','INC00023317','INC00024806','INC00026554',
'INC00023823','INC00029992','INC00023049','INC00028053','INC00028158','INC00030383','INC00033641','INC00030921','INC00032999',
'INC00025610','INC00030542','INC00024509','INC00023215','INC00025033','INC00025374',
'INC00033646','INC00033492','INC00033486','INC00033464','INC00033352','INC00033255','INC00033236','INC00033198','INC00033181',
'INC00033058','INC00033056','INC00032793','INC00032731','INC00032523','INC00032225','INC00032193','INC00031989','INC00031952',
'INC00031834','INC00031599','INC00031564','INC00031067','INC00029739','INC00028306','INC00027983','INC00027803','INC00027613',
'INC00025374','INC00025004','INC00023157','INC00020337','INC00020159','INC00015213') 
and SLA like ('%KM-13%');

update metrics.sla_incident_join 
SET stage ='Cancelled' 
where task in  ('INC00016127','INC00021079','INC00021125','INC00020980','INC00020882','INC00021909','INC00021872','INC00022147','INC00022503','INC00022072',
'INC00022262','INC00022823','INC00021214','INC00022949','INC00022553','INC00018976','INC00021428','INC00021721','INC00022730','INC00024058',
'INC00024616','INC00024663','INC00024856','INC00023872','INC00025264','INC00024417','INC00023434','INC00025117','INC00025629','INC00025524',
'INC00022830','INC00025918','INC00025920','INC00026028','INC00025278','INC00025788','INC00025917','INC00025919','INC00025921','INC00025923',
'INC00024625','INC00025914','INC00025922','INC00025924','INC00025787','INC00026025','INC00026036','INC00025786','INC00026026','INC00026035',
'INC00026020','INC00026037','INC00026039','INC00026024','INC00026029','INC00026038','INC00026040','INC00026041','INC00026042','INC00022403',
'INC00026015','INC00026043','INC00026414','INC00026030','INC00026027','INC00026031','INC00026044','INC00026032','INC00026033','INC00026034',
'INC00026018','INC00026021','INC00026023','INC00026372','INC00024541','INC00026428','INC00026425','INC00026427','INC00026421','INC00026424',
'INC00026426','INC00026429','INC00026745','INC00026430','INC00026445','INC00026434','INC00026437','INC00026440','INC00026443','INC00021917',
'INC00022626','INC00023958','INC00026446','INC00026781','INC00027177','INC00026441','INC00026438','INC00026432','INC00026792','INC00026978',
'INC00026435','INC00026436','INC00026444','INC00026433','INC00026439','INC00026447','INC00026782','INC00026784','INC00026775','INC00026783',
'INC00026789','INC00026790','INC00026791','INC00026773','INC00026780','INC00026786',
'INC00022270','INC00026442','INC00016951','INC00026848','INC00028221','INC00021383',
'INC00026080','INC00028162','INC00026912','INC00026619','INC00029086','INC00029552','INC00029571','INC00029890',
'INC00029621','INC00027597','INC00030251','INC00027601',
'INC00030315','INC00026697','INC00027184','INC00029132',
'INC00029447','INC00031762','INC00032121','INC00032451')
and SLA like ('%KM-13%');


DROP VIEW IF EXISTS metrics.KM_13;
CREATE VIEW metrics.KM_13
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC KM-13 WS B&F NonHW resol.'
	AND s.state = 'Closed' -- or 'Closed complete' || Need to be clarified
	AND s.stage = 'Completed';

-----------------------------------------------  FORMULA ----------------------------------------------

DROP TABLE IF EXISTS metrics.KM_13_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_13) t) <> 0
	(SELECT 'KM-13' AS KM,
		'Workstation break fix time to Resolve (non-Hardware)' AS Name, 
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Workstation Break/Fix Incidents successfully resolved within one (1) Business Day.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.KM_13_formula
	FROM metrics.KM_13 k
	GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-13' AS KM,
		'Workstation break fix time to Resolve (non-Hardware)' AS Name, 
		CAST(NULL AS varchar) AS 'opened_at_date',
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) AS 'company',
		CAST(NULL AS varchar) AS 'site',
		CAST(NULL AS varchar) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Workstation Break/Fix Incidents successfully resolved within one (1) Business Day.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.KM_13_formula);

-----------------------------------------------  FILTERS KM - 18  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

DROP VIEW IF EXISTS metrics.KM_18;
CREATE VIEW metrics.KM_18
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC KM-18 P1&2 resolution'
	AND s.state = 'Closed'
	AND s.stage = 'Completed';

-----------------------------------------------  FORMULA ----------------------------------------------

DROP TABLE IF EXISTS metrics.KM_18_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_18) t) <> 0
	(SELECT 'KM-18' AS KM, 
		'Incidents Priority Level 1 + 2 resolved' AS Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		100.00 AS Expected,
		95.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of the Incidents Priority Level 1+2 resolved in time.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.KM_18_formula
	FROM metrics.KM_18 k
	GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-18' AS KM, 
		'Incidents Priority Level 1 + 2 resolved' AS Name,
		CAST(NULL AS varchar) AS 'opened_at_date',
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) AS 'company',
		CAST(NULL AS varchar) AS 'site',
		CAST(NULL AS varchar) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.00 AS Expected,
		95.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of the Incidents Priority Level 1+2 resolved in time.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.KM_18_formula);

-----------------------------------------------  FILTERS KM - 19  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

update metrics.sla_incident_join 
SET has_breached = 0 
where task in ('INC00014945','INC00015013','INC00015122','INC00014861','INC00014859','INC00014860','INC00020494',
'INC00023966','INC00023821','INC00026349','INC00029380','INC00029156','INC00030275','INC00029661','INC00029887')
and sla = 'Infosys EUC KM-19 P3&4 resolution';


update metrics.sla_incident_join 
SET Stage = 'Cancelled' 
where task in ('INC00014794', 'INC00018976',
'INC00012423','INC00015249','INC00019535','INC00024822','INC00024317','INC00024421')
and sla = 'Infosys EUC KM-19 P3&4 resolution';

DROP VIEW IF EXISTS metrics.KM_19;
CREATE VIEW metrics.KM_19
AS
SELECT *,
	CONVERT(varchar, s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar, s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC KM-19 P3&4 resolution'
	AND s.state = 'Closed'
	AND s.stage = 'Completed';

-----------------------------------------------  FORMULA ----------------------------------------------

DROP TABLE IF EXISTS metrics.KM_19_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_19) t) <> 0
	(SELECT 'KM-19' AS KM,
		'Incidents Priority Level 3 + 4 resolved' As Name,
		k.opened_at_date,
		k.closed_at_date,
		CAST(k.company_name AS varchar) AS company,
		CAST(k.location AS varchar) AS site,
		CAST(k.location_country AS varchar) AS country,
		SUM(CASE WHEN k.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(k.has_breached) AS formula_part_2,
		100.00 AS Expected,
		95.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of the Incidents Priority Level 3+4 resolved in time.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.KM_19_formula
	FROM metrics.KM_19 k
	GROUP BY k.opened_at_date, k.closed_at_date, k.company_name, k.location, k.location_country)
ELSE
	(SELECT 'KM-19' AS KM,
		'Incidents Priority Level 3 + 4 resolved' As Name,
		CAST(NULL AS varchar) AS 'opened_at_date',
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) AS 'company',
		CAST(NULL AS varchar) AS 'site',
		CAST(NULL AS varchar) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.00 AS Expected,
		95.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of the Incidents Priority Level 3+4 resolved in time.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.KM_19_formula);

-----------------------------------------------  FILTERS KM - 20  -----------------------------------------------
-----------------------------------------------  FORMULA ----------------------------------------------
update metrics.sla_incident_join 
SET has_breached = 0 
where task in ('INC00014945','INC00015122')
and sla = 'Infosys EUC KM-20 Overdue Incidents';

update metrics.sla_incident_join 
SET stage = 'Cancelled'
where task in ('INC00015249')
and sla = 'Infosys EUC KM-20 Overdue Incidents';


DROP TABLE IF EXISTS metrics.KM_20_formula;
SELECT 'KM-20' AS KM, 
                'Overdue Incidents resolved' As Name, 
                k.opened_at AS 'opened_at_date',
                k.closed_at AS 'closed_at_date', 
                CAST(k.company_name AS varchar) AS company, 
                CAST(k.location AS varchar) AS site, 
                CAST(k.location_country AS varchar) AS country, 
                (SELECT COUNT(task) from   metrics.sla_incident_join  t  where 
				task in (SELECT task FROM  metrics.sla_incident_join  s WHERE  s.sla = 'Infosys EUC KM-19 P3&4 resolution' AND s.has_breached = 1 and s.stage = 'Completed') 
                        AND t.sla = 'Infosys EUC KM-20 Overdue Incidents' and t.has_breached = 0
						AND t.opened_at = k.opened_at
						AND t.closed_at = k.closed_at
						--AND t.company_name = k.company_name
						--AND t.location = k.location
						--AND t.location_country = k.location_country
						) AS formula_part_1,

                (SELECT COUNT(task) FROM  metrics.sla_incident_join  s 
                                WHERE  s.sla = 'Infosys EUC KM-19 P3&4 resolution' AND s.has_breached = 1 and s.stage = 'Completed'
								AND s.opened_at = k.opened_at
								AND s.closed_at = k.closed_at
							--	AND s.company_name = k.company_name
							--	AND s.location = k.location
							--	AND s.location_country = k.location_country 
								) AS formula_part_2,  
                100.00 AS Expected, 
                95.00 AS Minimum, 
                CONVERT(date, GETDATE()) AS Report_created_at, 
                'Percentage of the Incidents exceeded 10 (ten) Business Days.' AS 'Definition', 
                0 AS 'empty', 
                1 AS 'in_pilot', 
                1 AS 'sign_off_by_RWE' 
        INTO metrics.KM_20_formula
        FROM metrics.sla_incident_join  k
		WHERE k.state = 'Closed'
		AND k.stage = 'Completed' 
        GROUP BY k.opened_at, k.closed_at, k.company_name, k.location, k.location_country;


---------------------KM-01 added on 08/06/2020 -----------------------

DROP VIEW IF EXISTS metrics.KM_01_6_20;
CREATE VIEW metrics.KM_01_6_20
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC CSL-01 First Call Res. 06/20'
	AND s.state = 'Closed' 
	AND s.stage = 'Completed';

	----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.KM_01_6_20_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.KM_01_6_20) t) <> 0
	(SELECT 'KM-01' AS KM,
		'Service Desk Tickets Escalated to Level 2' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 1 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		30.00 AS Expected,
		33.50 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The number of tickets that are escalated from the Service Desk to a Level 2 Support Group for resolution.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.KM_01_6_20_formula
	FROM metrics.KM_01_6_20 c
GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'KM-01' AS KM,
		'Service Desk Tickets Escalated to Level 2' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		30.00 AS Expected,
		33.50 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The number of tickets that are escalated from the Service Desk to a Level 2 Support Group for resolution.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.KM_01_6_20_formula);

			
			DROP TABLE IF EXISTS metrics.KM_01_formula;
				SELECT x.*
				INTO metrics.KM_01_formula
					FROM
					(
					SELECT * 
					FROM metrics.KM_01_formula_old 
					UNION
					Select * 
					from metrics.KM_01_6_20_formula
					) x;
