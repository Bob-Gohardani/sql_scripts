DROP TABLE IF EXISTS prod.KM_ALL;
SELECT x.*
INTO prod.KM_ALL
FROM (
	SELECT * 
	FROM metrics.KM_01_formula
	UNION
	Select * from metrics.KM_01_6_20_formula
	UNION 
	SELECT *
	FROM metrics.KM_04_formula
	UNION
	SELECT * 
	FROM metrics.KM_07_formula
	UNION
	SELECT * 
	FROM metrics.KM_10_formula
	UNION
	SELECT * 
	FROM metrics.KM_13_formula
	UNION
	SELECT * 
	FROM metrics.KM_18_formula
	UNION
	SELECT * 
	FROM metrics.KM_19_formula
	UNION
	SELECT *
	FROM metrics.KM_20_formula
	UNION 
	SELECT 'KM-03' AS CSL,
		'Aging standard hardware in stock' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		100.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Processing standard hardware in stock follows FiFo (First-in-first-out) principle and no item is more than thirty (30) days unused. Unused in this sense means the time prior delivery to an Authorized User and the time after returning from the Authorized User and completion of the applicable follow-on step (such as delivering to the next Authorized User, returning to the lease provider, disposal).' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	
	SELECT 'KM-11' AS CSL,
		'Non-packaged software installations in time' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.0 AS Expected,
		90.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of non-packaged Software installed within three (3) Business Days.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	SELECT 'KM-12' AS CSL,
		'Non-standard T&M IMAC completed in time' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.0 AS Expected,
		90.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of non-standard T&M IMACs completed within ten (10) Business Days.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	UNION
	SELECT 'KM-14' AS CSL,
		'Prepare workstation for re-use within five (5) Business Days' AS Name,
		CAST(NULL AS varchar) as opened_at_date,
		CONVERT(varchar, DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar) as company,
		CAST(NULL AS varchar) as site,
		CAST(NULL AS varchar) as country,
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.0 AS Expected,
		90.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of workstations prepared for re-use within five (5) Business Days.' AS 'Definition',
		1 AS 'empty',
		0 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
		) x
