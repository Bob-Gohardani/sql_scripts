update metrics.incident_SLA_join 
SET has_breached = 0 
where number in ('INC00012732') 
AND sla like ('%CSL-01%');


DROP VIEW IF EXISTS metrics.CSL_01;
CREATE VIEW metrics.CSL_01
AS
SELECT DISTINCT i.opened_at,
	i.closed_at,
	i.company_name,
	i.location,
	i.location_country,
	i.sla,
	i.stage,
	i.has_breached,
	i.number,
CONVERT(varchar(max), i.opened_at, 107) AS opened_at_date,
CONVERT(varchar(max), i.closed_at, 107) AS closed_at_date
FROM metrics.incident_SLA_join i
WHERE i.category IN ('Failure', 'Request')
AND i.contact_type in ('Phone' )
AND i.state = 'Closed'
AND i.[service_offering.supported_by] = 'Resolvable by Service Desk';

----------------------------------------------- FORMULA  -----------------------------------------------


DROP TABLE IF EXISTS metrics.CSL_01_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_01) t) <> 0
	(SELECT 'CSL-01' AS CSL,
              'First call Resolution Rate' AS Name,
              c.opened_at_date,
              c.closed_at_date,
              CAST(c.company_name AS varchar(max)) AS company,
              CAST(c.location AS varchar(max)) AS site,
              CAST(c.location_country AS varchar(max)) AS 'country',
              sum((CASE WHEN c.sla = 'Infosys EUC CSL-01 First Call Resolution' AND c.stage = 'Completed' AND c.has_breached = 0 THEN 1 ELSE 0 END)) AS formula_part_1,
              COUNT(distinct(c.number)) as formula_part_2,
              70.0 AS Expected,
              66.50 AS Minimum,
              CONVERT(date, GETDATE()) AS Report_created_at,
			  'The percentage of Calls resolved by the Service Desk on the first Call.' AS 'Definition',
			  0 AS 'empty',
			  1 AS 'in_pilot',
			  1 AS 'sign_off_by_RWE'
       INTO metrics.CSL_01_formula
       FROM metrics.CSL_01 c
GROUP BY c.opened_at_date, c.closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-01' AS CSL,
		'First call Resolution Rate' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		70.0 AS Expected,
		66.50 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Calls resolved by the Service Desk on the first Call.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_01_formula);


-------------------------------------------------------------------------------
UPDATE metrics.CSL_01_formula
SET formula_part_2 = 0
WHERE name = 'First call Resolution Rate'
	AND company = 'RWE Generation SE' AND SITE = 'Huyssenallee 2, 45128, Essen, DE'
	AND formula_part_2 = 1 
	AND closed_at_date = 'Dec 11, 2019'
	and opened_at_date = 'Dec 06, 2019';
-------------------------------------------------------------------------------

-----------------------------------------------  FILTERS CSL-02  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

Update prod.final_incident 
Set reopen_count = 0 
where number = 'INC00013170';

DROP VIEW IF EXISTS metrics.CSL_02;
CREATE VIEW metrics.CSL_02
AS
SELECT *,
	CONVERT(varchar(max), i.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), i.closed_at, 107) AS closed_at_date
FROM prod.final_incident i
WHERE i.opened_by_group_name = 'Service Desk'
	AND i.category IN ('Failure', 'Request')
	AND i.[service_offering.supported_by] IN ('Resolvable by Service Desk', 'Infosys Responsibility')
	AND i.state = 'Closed'
	AND i.assignment_group = 'Service Desk';


----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_02_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_02) t) <> 0
	(SELECT 'CSL-02' AS CSL,
		'Percentage of Incident Records Closed and Not Reopened' AS Name,
		c.opened_at_date,
		c.closed_at_date,
		CAST(c.[caller_id.company.name] AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site, -- CHANGE 12.09.2019 from location.name to location due to laction would be fetch from ether location column from incident or [request.delivery_address] column from request table
		CAST(c.[caller_id.location.country] AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.reopen_count = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.reopen_count) AS formula_part_2,
		98.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Incident Records that are closed and are not reopened within three (3) Business Days.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_02_formula
	FROM metrics.CSL_02 c
	GROUP BY c.opened_at_date, c.closed_at_date, c.[caller_id.company.name], c.location, c.[caller_id.location.country])
ELSE
	(SELECT 'CSL-02' AS CSL,
		'Percentage of Incident Records Closed and Not Reopened' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		98.0 AS Expected,
		95.0 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Incident Records that are closed and are not reopened within three (3) Business Days.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_02_formula);


-----------------------------------------------  FILTERS CSL-07  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

update metrics.sla_incident_join 
SET has_breached = 0 
where task in ('INC00010981','INC00011177', 'INC00011579', 'INC00011438', 'INC00012458','INC00010893',
'INC00011831','INC00010481','INC00011911','INC00012376','INC00013427','INC00013193','INC00014150','INC00013609',
'INC00013193','INC00014150','INC00013609','INC00015257','INC00013000')
AND sla like ('%CSL-07%'); 

update metrics.sla_incident_join 
SET stage = 'Cancelled'   
where task in ('INC00011229','INC00016790','INC00017181','INC00013936') 
AND sla like ('%CSL-07%');


DROP VIEW IF EXISTS metrics.CSL_07;
CREATE VIEW metrics.CSL_07
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC CSL-07 WS B&F response'
	AND s.state = 'Closed'  -- or "Closed Completed" || Need to be clarified
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_07_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_07) t) <> 0
	(SELECT 'CSL-07' AS CSL,
		'Workstation Break/Fix Time to Respond (Hardware & Non-Hardware)' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstation Break/Fix Incidents responded to within [four (4) hours] during Business Hours.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_07_formula
	FROM metrics.CSL_07 c
GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-07' AS CSL,
		'Workstation Break/Fix Time to Respond (Hardware & Non-Hardware)' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstation Break/Fix Incidents responded to within [four (4) hours] during Business Hours.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_07_formula);


-----------------------------------------------  FILTERS CSL-08  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

DROP VIEW IF EXISTS metrics.CSL_08;
CREATE VIEW metrics.CSL_08
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_incident_join s
WHERE s.sla = 'Infosys EUC CSL-08 WS B&F HW resolution'
	AND s.state = 'Closed' -- or "Closed Completed" || Need to be clarified
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_08_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_08) t) <> 0
	(SELECT 'CSL-08' AS CSL,
		'Workstation Break/Fix Time to Resolve (Hardware)' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Workstation Break/Fix Incidents successfully resolved within 1 (one) Business Days (end of Next Business Day) for tickets raised before 16:00 Local time. For tickets raised after this the resolution shall be measured at the end of the 3rd working day.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.CSL_08_formula
	FROM metrics.CSL_08 c
GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-08' AS CSL,
		'Workstation Break/Fix Time to Resolve (Hardware)' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Workstation Break/Fix Incidents successfully resolved within 1 (one) Business Days (end of Next Business Day) for tickets raised before 16:00 Local time. For tickets raised after this the resolution shall be measured at the end of the 3rd working day.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
		INTO metrics.CSL_08_formula);

-----------------------------------------------  FILTERS CSL-09  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

update metrics.sla_request_join
SET has_breached = 0 
where task in ('RITM0010398','RITM0010455','RITM0010420','RITM0010428','RITM0010494','RITM0011281','RITM0010495','RITM0011272');

DROP VIEW IF EXISTS metrics.CSL_09;
CREATE VIEW metrics.CSL_09
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s
WHERE s.sla = 'Infosys EUC CSL-09 Hard IMAC'
	AND s.state = 'Closed Complete' -- or 'Closed' || Need to be clarified
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_09_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_09) t) <> 0
	(SELECT 'CSL-09' AS CSL,
		'Hard IMAC Completed On-Time' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Measures the percentage of Hard IMACs successfully completed within [three (3)] Business Days' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_09_formula
	FROM metrics.CSL_09 c
	GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-09' AS CSL,
		'Hard IMAC Completed On-Time' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Measures the percentage of Hard IMACs successfully completed within [three (3)] Business Days' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_09_formula);

-----------------------------------------------  FILTERS CSL-10  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

DROP VIEW IF EXISTS metrics.CSL_10;
CREATE VIEW metrics.CSL_10
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s
WHERE s.sla = 'Infosys EUC CSL-10 WS Installation asap'
	AND s.state = 'Closed Complete' -- or 'Closed' || Need to be clarified
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_10_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_10) t) <> 0
	(SELECT 'CSL-10' AS CSL,
		'New Workstation Installation a.s.a.p.' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstations and their related peripheral Equipment and Software successfully installed a.s.a.p. but not later than within one (1) Business Day (end of Next Business Day) for tickets raised before 16:00 Local time. For tickets raised after this the resolution shall be measured at the end of the 3rd working day.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.CSL_10_formula
	FROM metrics.CSL_10 c
	GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-10' AS CSL,
		'New Workstation Installation a.s.a.p.' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstations and their related peripheral Equipment and Software successfully installed a.s.a.p. but not later than within one (1) Business Day (end of Next Business Day) for tickets raised before 16:00 Local time. For tickets raised after this the resolution shall be measured at the end of the 3rd working day.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
		INTO metrics.CSL_10_formula);

-----------------------------------------------  FILTERS CSL-11  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------
update metrics.sla_request_join
SET has_breached = 0 
where task in ('RITM0011312','RITM0011515');

DROP VIEW IF EXISTS metrics.CSL_11;
CREATE VIEW metrics.CSL_11
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s
WHERE s.sla = 'Infosys EUC CSL-11 WS Installation 2days'
	AND s.state = 'Closed Complete' -- or 'Closed' || Need to be clarified
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_11_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_11) t) <> 0
	(SELECT 'CSL-11' AS CSL,
		'New Workstation Installation within two (2) Business Days' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(c.has_breached) AS formula_part_2,
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstations and their related peripheral Equipment and Software successfully installed within two (2) Business Days.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_11_formula
	FROM metrics.CSL_11 c
	GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-11' AS CSL,
		'New Workstation Installation within two (2) Business Days' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		95.00 AS Expected,
		90.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of Workstations and their related peripheral Equipment and Software successfully installed within two (2) Business Days.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_11_formula);

-----------------------------------------------  FILTERS CSL-13  -----------------------------------------------
-----------------------------------------------  Create VIEW  -----------------------------------------------

DROP VIEW IF EXISTS metrics.CSL_13;
CREATE VIEW metrics.CSL_13
AS
SELECT *,
	CONVERT(varchar(max), s.opened_at, 107) AS opened_at_date,
	CONVERT(varchar(max), s.closed_at, 107) AS closed_at_date
FROM metrics.sla_request_join s														
WHERE (s.sla LIKE '%CSL-06%' or s.sla LIKE '%CSL-09%' OR s.sla LIKE '%CSL-10%' OR s.sla LIKE '%CSL-11%' OR s.sla LIKE '%CSL-20%' OR s.sla LIKE '%KM-10%' OR s.sla LIKE '%KM-11%' OR s.sla LIKE '%KM-12%') 
	AND s.state = 'Closed Complete' 
	AND s.stage = 'Completed';

----------------------------------------------- FORMULA  -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_13_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM metrics.CSL_13) t) <> 0
	(SELECT 'CSL-13' AS CSL,
		'Request fulfilment Time' AS Name,
		opened_at_date,
		closed_at_date,
		CAST(c.company_name AS varchar(max)) AS company,
		CAST(c.location AS varchar(max)) AS site,
		CAST(c.location_country  AS varchar(max)) AS 'country',
		SUM(CASE WHEN c.has_breached = 0 THEN 1 ELSE 0 END) AS formula_part_1,
		COUNT(*) AS formula_part_2,
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of stated fulfillment times met.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
	INTO metrics.CSL_13_formula
	FROM metrics.CSL_13 c
	GROUP BY opened_at_date, closed_at_date, c.company_name, c.location, c.location_country)
ELSE
	(SELECT 'CSL-13' AS CSL,
		'Request fulfilment Time' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The percentage of stated fulfillment times met.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		0 AS 'sign_off_by_RWE'
		INTO metrics.CSL_13_formula);

-----------------------------------------------  FILTERS CSL-03  -----------------------------------------------
-----------------------------------------------       AVAYA      -----------------------------------------------

DROP TABLE IF EXISTS metrics.CSL_03_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM input.avaya) a) <> 0
	(SELECT 'CSL-03' AS CSL,
		'Service Desk Speed to Answer' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), a.Date, 107) AS closed_at_date,
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		a.[Split/Skill] as 'country',
		SUM(a.[Calls In SLA]) AS formula_part_1,
		SUM(a.[ACD Calls]) AS formula_part_2,
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The number of calls that are responded to within twenty (20) seconds after the Authorized User selects the option to speak to a Service Desk.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_03_formula
	FROM input.avaya a
	GROUP BY a.Date, a.[Split/Skill])
ELSE
	(SELECT 'CSL-03' AS CSL,
		'Service Desk Speed to Answer' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		90.00 AS Expected,
		85.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'The number of calls that are responded to within twenty (20) seconds after the Authorized User selects the option to speak to a Service Desk.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_03_formula);

-----------------------------------------------  FILTERS CSL-04  -----------------------------------------------
-----------------------------------------------       AVAYA      -----------------------------------------------


DROP TABLE IF EXISTS metrics.CSL_04_formula;
IF (SELECT COUNT(*) FROM (SELECT top 1 * FROM input.avaya) a) <> 0
	(SELECT 'CSL-04' AS CSL,
		'Service Desk Call Abandon Rate' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), a.Date, 107) AS closed_at_date,
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		a.[Split/Skill] as 'country',
		-- SUM(a.[Aban Calls]) AS formula_part_1,
		SUM(a.[Aban Calls]) - (SUM(a.[Aban Calls1]) +  SUM(a.[Aban Calls2]) +  SUM(a.[Aban Calls3]) +  SUM(a.[Aban Calls4])) AS formula_part_1,
		SUM(a.[ACD Calls]) + SUM(a.[Aban Calls]) AS formula_part_2,
		7.00 AS Expected,
		8.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Authorized User Calls that are abandoned after selecting the Voice Response Unit menu item to speak to a Service Desk agent.' AS 'Definition',
		0 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
	INTO metrics.CSL_04_formula
	FROM input.avaya a
	GROUP BY a.Date, a.[Split/Skill])
ELSE
	(SELECT 'CSL-04' AS CSL,
		'Service Desk Call Abandon Rate' AS Name,
		CAST(NULL AS varchar(max)) AS 'opened_at_date',
		CONVERT(varchar(max), DATEADD(DAY, -1, GETDATE()), 107) AS 'closed_at_date',
		CAST(NULL AS varchar(max)) AS 'company',
		CAST(NULL AS varchar(max)) AS 'site',
		CAST(NULL AS varchar(max)) AS 'country',
		NULL AS 'formula_part_1',
		NULL AS 'formula_part_2',
		7.00 AS Expected,
		8.00 AS Minimum,
		CONVERT(date, GETDATE()) AS Report_created_at,
		'Percentage of Authorized User Calls that are abandoned after selecting the Voice Response Unit menu item to speak to a Service Desk agent.' AS 'Definition',
		1 AS 'empty',
		1 AS 'in_pilot',
		1 AS 'sign_off_by_RWE'
		INTO metrics.CSL_04_formula)