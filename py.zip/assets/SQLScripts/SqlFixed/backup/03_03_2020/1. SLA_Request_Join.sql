DROP TABLE IF EXISTS metrics.sla_request_join;
SELECT s.sla,
s.sys_id,
s.has_breached,
s.active,
s.business_duration,
s.pause_duration,
s.pause_time,
s.task,
r.cat_item,
r.stage,
r.assignment_group,
r.company,
r.contact_type,
r.opened_at,
r.closed_at,
r.approval_set,
r.state,
r.priority,
r.reassignment_count,
r.[request.requested_for.company.country] AS 'company_country',
r.[request.requested_for.company.name] AS 'company_name',
r.[request.requested_for.location.country] AS 'location_country',
r.[request.delivery_address] AS 'location'
INTO metrics.sla_request_join
FROM input.sla s
LEFT JOIN input.requested r ON r.number = s.task
WHERE s.task LIKE 'RITM%'