DROP TABLE IF EXISTS input.avaya
--- SPLIT ---
SELECT *
INTO input.avaya
FROM rwe_etl_production.input.avaya