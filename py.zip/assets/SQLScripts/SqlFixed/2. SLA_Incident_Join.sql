DROP TABLE IF EXISTS #temp_user_group_join;
SELECT u.[user],
	u.[group],
	g.[name],
	g.u_domain
INTO #temp_user_group_join 
FROM input.user_group_id u
LEFT JOIN input.group_id g ON  g.sys_id = u.[group] 
WHERE g.name = 'Service Desk';

DROP TABLE IF EXISTS #temp_part_1;
SELECT id.sys_id,
	id.opened_by,
	u.[group] AS 'opened_by_group_id',
	u.[name] AS 'opened_by_group_name',
	u.u_domain AS 'opened_by_group_u_domain',
	id.assigned_to,
	id.closed_by
INTO #temp_part_1
FROM input.incident_id id
LEFT JOIN #temp_user_group_join u ON u.[user] = id.opened_by;



DROP TABLE IF EXISTS #temp_part_2;
SELECT te.sys_id,
	te.opened_by,
	te.opened_by_group_id,
	te.opened_by_group_name,
	te.opened_by_group_u_domain,
	te.closed_by,
	u.[group] AS 'closed_by_group_id',
	u.[name] AS 'closed_by_group_name',
	u.u_domain AS 'closed_by_group_u_domain',
	te.assigned_to
INTO #temp_part_2
FROM #temp_part_1 te
LEFT JOIN #temp_user_group_join u ON u.[user] = te.closed_by;

DROP TABLE IF EXISTS #temp_part_3;
SELECT te.sys_id,
	te.opened_by,
	te.opened_by_group_id,
	te.opened_by_group_name,
	te.opened_by_group_u_domain,
	te.closed_by,
	te.closed_by_group_id,
	te.closed_by_group_name,
	te.closed_by_group_u_domain,
	te.assigned_to,
	u.[group] AS 'assigned_to_group_id',
	u.[name] AS 'assigned_to_group_name',
	u.u_domain AS 'assigned_to_group_u_domain'
INTO #temp_part_3
FROM #temp_part_2 te
LEFT JOIN #temp_user_group_join u ON u.[user] = te.assigned_to;

DROP TABLE IF EXISTS prod.final_incident;
SELECT i.*
	  ,t.opened_by
	  ,t.opened_by_group_id
	  ,t.opened_by_group_name
	  ,t.opened_by_group_u_domain
	  ,t.closed_by
	  ,t.closed_by_group_id
	  ,t.closed_by_group_name
	  ,t.closed_by_group_u_domain
	  ,t.assigned_to
	  ,t.[assigned_to_group_id]
	  ,t.assigned_to_group_name
	  ,t.assigned_to_group_u_domain
	  ,GETDATE() AS Report_created_at
INTO prod.final_incident
FROM input.incident i
LEFT JOIN #temp_part_3 t ON t.sys_id = i.sys_id;

DROP TABLE IF EXISTS metrics.sla_incident_join;
SELECT s.sla,
s.sys_id,
s.has_breached,
s.stage,
s.active,
s.business_duration,
s.pause_duration,
s.pause_time,
s.task,
i.category,
i.incident_state,
i.reopen_count,
i.subcategory,
i.service_offering,
i.[service_offering.support_group],
i.[service_offering.supported_by],
i.assignment_group,
i.contact_type,
i.opened_at,
i.closed_at,
i.state,
i.priority,
i.reassignment_count,
i.[caller_id.company.country] AS 'company_country',
i.[caller_id.company.name] AS 'company_name',
i.[caller_id.location.country] AS 'location_country',
i.location,
i.opened_by,
i.opened_by_group_id,
i.opened_by_group_name,
i.opened_by_group_u_domain,
i.closed_by,
i.closed_by_group_id,
i.closed_by_group_name,
i.closed_by_group_u_domain,
i.assigned_to,
i.assigned_to_group_id,
i.assigned_to_group_name,
i.assigned_to_group_u_domain,
i.sys_updated_on
INTO metrics.sla_incident_join
FROM input.sla s
LEFT JOIN prod.final_incident i ON i.number = s.task
WHERE s.task LIKE 'INC%';


-- adding  INC00010855

INSERT INTO metrics.sla_incident_join (sla, 
task, 
       location, 
       stage, 
       has_breached, 
       company_name, 
       location_country, 
       opened_at, 
       closed_at, 
       category, 
       contact_type, 
       state,
       [service_offering.supported_by],
       -- NEW --
       incident_state,
       assignment_group,
       opened_by_group_name,
       opened_by_group_u_domain,
       closed_by_group_name,
       closed_by_group_u_domain,
       assigned_to_group_name,
       assigned_to_group_u_domain)
VALUES (
'Infosys EUC KM-20 Overdue Incidents',
'INC00010855', -- number
'Altenessener Str. 27, 45141, Essen, DE', -- location
'Completed', -- stage
0, -- has_breached
'RWE Supply & Trading GmbH', -- company_name
'DE', -- location_country
CONVERT(DATETIME, '2019-10-24 14:28:20.000', 121), -- opened_at
CONVERT(DATETIME, '2020-01-13 17:00:05.000', 121), -- closed_at
'Failure',  
'Phone',
'Closed',
'Resolvable by Service Desk',
-----------
'Closed', -- incident_state
'Hypercare', -- assignment_group
'Service Desk', -- opened_by_group_name
'Infosys', -- opened_by_group_u_domain
null, -- closed_by_group_name
null, -- closed_by_group_u_domain
null, -- assigned_to_group_name
null-- assigned_to_group_u_domain
)