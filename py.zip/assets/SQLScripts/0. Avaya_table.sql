DROP TABLE IF EXISTS input.avaya;
SELECT *
INTO input.avaya
FROM rwe_etl_production.input.avaya