import os


class SourceConfiguration:
    # Inforation about SQL Server
    SQL_SERVER = 'WZAH3001.energy.local,3952'
    # SQL_DATABASE = 'temporary_database'
    SQL_DATABASE = 'rwe_etl_production'
    SQL_DRIVER = 'SQL Server'
    # Inforation about path to the MidServer
    MID_SERVER_PATH = 'W:\\'
    # Inforation about CSV format of files stored on MidServer
    CSV_ENCODING = 'ISO-8859-1'
    # inforamtion about shelve files
    SHELVE_FOLDER = 'shelve'
    SHELVE_FILENAME = 'ETL_information_{SQL_DATABASE}'.format(SQL_DATABASE=SQL_DATABASE)
    # SQL Scripts
    SQL_PATH = os.path.join('assets', 'SQLScripts')
