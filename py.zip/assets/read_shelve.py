import os
from pathlib import Path
import shelve
from config import SourceConfiguration
import dbm


CONFIG = SourceConfiguration()
SHELVE_FOLDER_PATH = os.path.join(os.getcwd(), CONFIG.SHELVE_FOLDER)
SHELVE_FILES_PATH = os.path.join(SHELVE_FOLDER_PATH, CONFIG.SHELVE_FILENAME)
if not Path(SHELVE_FOLDER_PATH).is_dir():
    raise FileNotFoundError("No shelve folder, no shelve files found. Creating new shelve files.")
else:
    try:
        shelve_obj = shelve.open(filename=SHELVE_FILES_PATH, flag='w', writeback=True)
    except dbm.error:
        raise PermissionError("Problems with the shelve files. Creating new shelve files.")
        
SHELVE_CONTENT = shelve_obj['items']
for item in SHELVE_CONTENT:
    print(item)

shelve_obj.close()