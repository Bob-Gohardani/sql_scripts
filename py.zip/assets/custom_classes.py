import os
import urllib
import re
from datetime import date
from operator import itemgetter
import sqlalchemy
import pandas as pd


class DatabaseConnectionWrapper:
    '''
    The DatabaseConnectionWrapper object contains information about the SQL Database.

    Parameters
    -----------
    server: str
        pass
    database: str
        pass
    driver: str
        pass

    Attributes
    -----------
    server: str
        pass
    database: str
        pass
    driver: str
        pass
    '''
    def __init__(self, server, database, driver):
        self.server = server
        self.database = database
        self.driver = driver
        self.engine = None

    def create_engine(self):
        connection_string = f"DRIVER={self.driver}; Server={self.server}; DATABASE={self.database}"
        params = urllib.parse.quote_plus(connection_string)
        self.engine = sqlalchemy.create_engine(f"mssql:///?odbc_connect={params}")

    def create_connection(self):
        return self.engine.connect()

    @staticmethod
    def ping_sql_server(sql_server_address):
        '''
            Ping the server using given address.

            Parameters
            ----------
            SQL_Server: string
                This variable contains SQL Server address.

            Returns
            ----------
            : boolean
                The function returns 0 if the connection was established,
                1 otherwise.
        '''
        # -5 omits port from the SQL Server address.
        return os.system("ping " + sql_server_address[:-5])


class DataPreprocessingClass:
    def __init__(self, filename, last_update, columns_to_correct,
                 drop_duplicates_on, sorted_files_list=None):
        self.filename = filename
        self.last_update = last_update
        self.columns_to_be_corrected = columns_to_correct
        self.drop_duplicates_on = drop_duplicates_on
        self.sorted_files_list = sorted_files_list

    @staticmethod
    def validate_and_drop_columns(dataframe, columns_to_save):
        oryginal_columns_list = list(dataframe)
        for column in columns_to_save:
            if column not in oryginal_columns_list:
                raise KeyError(f"Column {column} no in dataframe")
        return dataframe.filter(columns_to_save)

    @staticmethod
    def get_date_from_string(filename):
        regex_pattern = '[0-9]{14}'
        file_timestamp = re.search(regex_pattern, filename).group()
        year = int(file_timestamp[:4])
        month = int(file_timestamp[4:6])
        day = int(file_timestamp[6:8])
        return date(year, month, day)

    @staticmethod
    def to_datetime(dataframe, columns_list):
        for item in columns_list:
            dataframe[item] = pd.to_datetime(dataframe[item], dayfirst=True)
        return dataframe

    def extract_and_sort(self, full_files_list):
        # Creating list of dictionaris, every dict has two keys: file_path and timestamp
        regex_pattern = '^({})'.format(self.filename)
        filtered_files_list = [file_ for file_ in full_files_list if re.search(regex_pattern, file_)]
        temp_list = []
        for file_ in filtered_files_list:
            temp_dict = {}
            temp_dict['filename'] = file_
            temp_dict['timestamp'] = self.get_date_from_string(file_)
            temp_list.append(temp_dict)
        # Sorting list of dictionries by their common key: timestamp
        self.sorted_files_list = sorted(temp_list, key=itemgetter('timestamp'))

    def filter_by_last_update(self):
        if not self.last_update:
            return [item['filename'] for item in self.sorted_files_list]

        date_now = date.today()
        date_diff = date_now - self.last_update
        days_past = date_diff.days

        filtered_files_list = []
        for item in self.sorted_files_list:
            dif = date_now - item['timestamp']
            if dif.days <= days_past:
                filtered_files_list.append(item['filename'])
        return filtered_files_list

    def concatenate_files(self, files_path_list, csv_encoding):
        start_df = pd.read_csv(files_path_list[0], encoding=csv_encoding, keep_default_na=False)
        if self.drop_duplicates_on == 'All':
            self.drop_duplicates_on = list(start_df)

        start_df = start_df.drop_duplicates(self.drop_duplicates_on, keep='last')
        if files_path_list[1:]: # check if files_path_list contains more then one element
            for item in files_path_list[1:]:
                update_df = pd.read_csv(item, encoding=csv_encoding, keep_default_na=False)
                if update_df.empty:
                    continue
                if self.drop_duplicates_on:
                    start_df = pd.concat([start_df, update_df], sort=False)
                    start_df = start_df.drop_duplicates(self.drop_duplicates_on, keep='last')
                else:
                    start_df = pd.concat([start_df, update_df], sort=False)
                start_df.reset_index(drop=True, inplace=True)
        if not self.columns_to_be_corrected:
            return start_df
        final_table = self.to_datetime(start_df, self.columns_to_be_corrected)
        return final_table


class SQLOperationClass:
    def __init__(self, engine):
        self.engine = engine

    def drop_table(self, schema, table_name):
        drop_text = 'DROP TABLE {schema}.{table}'.format(schema=schema, table=table_name)
        drop_query = sqlalchemy.text(drop_text)
        with self.engine.connect() as coursor:
            coursor.execution_options(autocommit=True).execute(drop_query)

    def to_sql(self, dataframe, schema, table_name, if_exists='replace'):
        dataframe.to_sql(name=table_name, con=self.engine, schema=schema, if_exists=if_exists, index=False)

    def merge_tables(self, main_table, temp_table, merge_on, full_columns_list, schema):
        if isinstance(merge_on, (list, tuple, set)):
            merge_on_str = ' AND '.join(['TAR.[{table_name}] = SRC.[{table_name}]'.format(table_name=item) for item in merge_on])
        else:
            merge_on_str = 'TAR.[{table_name}] = SRC.[{table_name}]'.format(table_name=merge_on)

        update_str = ', '.join(['TAR.[{table_name}] = SRC.[{table_name}]'.format(table_name=item) for item in full_columns_list])
        full_columns_str = ', '.join(['[{}]'.format(item) for item in full_columns_list])
        update_values = ', '.join(['SRC.[{table_name}]'.format(table_name=item) for item in full_columns_list])

        merge_txt = 'MERGE {schema}.{main_table} AS TAR\
                    USING {schema}.{temp_table} AS SRC\
                    ON ({merge_on})\
                    WHEN MATCHED THEN UPDATE SET {update_str}\
                    WHEN NOT MATCHED BY TARGET THEN INSERT ({full_columns_str})\
                    VALUES ({update_values});'.format(schema=schema,
                                                      main_table=main_table,
                                                      temp_table=temp_table,
                                                      merge_on=merge_on_str,
                                                      update_str=update_str,
                                                      full_columns_str=full_columns_str,
                                                      update_values=update_values)
        merge_query = sqlalchemy.text(merge_txt)

        with self.engine.connect() as coursor:
            coursor.execution_options(autocommit=True).execute(merge_query)
